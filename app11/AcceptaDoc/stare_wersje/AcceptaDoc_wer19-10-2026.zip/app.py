import os
import io
import shutil
import hashlib
import re
from datetime import datetime, timezone
from functools import wraps
from flask import (Flask, render_template, request, redirect, url_for,
                   flash, session, send_file, jsonify, abort, g)
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from db import get_db, init_db, log_event
import pdf_report
import helps

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data', 'products')

app = Flask(__name__)
app.secret_key = os.urandom(32)
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100 MB

ALLOWED_EXTENSIONS = {'pdf', 'xlsx', 'xls', 'docx', 'doc', 'jpg', 'jpeg', 'png', 'dwg', 'dxf', 'step', 'stp', 'iges', 'igs', 'csv', 'txt'}

ROLES = ['Technolog', 'Konstruktor', 'Produkcja - elementy', 'Produkcja - szycie',
         'Produkcja - zgrzewanie', 'Kontrola jakości', 'Administrator']

FILE_CATEGORIES = ['documents', 'bom', 'drawings', 'prototype_photos', 'other']
FILE_CATEGORY_LABELS = {
    'documents': 'Dokumentacja główna',
    'bom': 'BOM (lista materiałów)',
    'drawings': 'Rysunki techniczne',
    'prototype_photos': 'Zdjęcia prototypu',
    'other': 'Inne'
}

# ── helpers ───────────────────────────────────────────────────────────────────

def _utc_now_str():
    """Aktualny czas UTC w formacie zgodnym z domyślnymi wartościami w bazie."""
    return datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if 'user_id' not in session:
                return redirect(url_for('login'))
            if session.get('role') not in roles:
                flash('Brak uprawnień do tej operacji.', 'danger')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated
    return decorator

def current_user():
    if 'user_id' in session:
        db = get_db()
        return db.execute('SELECT * FROM users WHERE id=?', (session['user_id'],)).fetchone()
    return None

def parse_product_number(number):
    """Parse 063-1026-001 -> client=063, period=1026, seq=001"""
    m = re.match(r'^(\d{3})-(\d{4})-(\d{3})$', number)
    if m:
        return m.group(1), m.group(2), m.group(3)
    return None, None, None

def get_file_dir(product_number, revision_letter, version_num, category):
    client, _, _ = parse_product_number(product_number)
    if not client:
        client = 'other'
    return os.path.join(DATA_DIR, client, product_number,
                        f'revision_{revision_letter}',
                        f'version_{version_num:03d}',
                        category)

def server_filename(product_number, revision_letter, version_num, category, orig_name, idx):
    cat_map = {'documents': 'DOKUMENTACJA', 'bom': 'BOM',
               'drawings': 'RYSUNEK', 'prototype_photos': 'ZDJECIE', 'other': 'INNE'}
    ext = orig_name.rsplit('.', 1)[-1].upper() if '.' in orig_name else 'BIN'
    base = cat_map.get(category, 'PLIK')
    return f"{product_number}_REV{revision_letter}_V{version_num:03d}_{base}_{idx:03d}.{ext.lower()}"

def check_stage1_complete(db, revision_id, doc_version_id):
    """Check if all required roles have valid approvals for this doc version."""
    required = db.execute(
        'SELECT role FROM required_roles WHERE revision_id=?', (revision_id,)
    ).fetchall()
    if not required:
        return False
    for row in required:
        a = db.execute(
            '''SELECT id FROM approvals
               WHERE doc_version_id=? AND role=? AND decision="AKCEPTUJE" AND validity="WAZNA"''',
            (doc_version_id, row['role'])
        ).fetchone()
        if not a:
            return False
    return True

def check_open_corrections(db, doc_version_id):
    c = db.execute(
        '''SELECT id FROM correction_requests
           WHERE doc_version_id=? AND status NOT IN ("ZAMKNIETE","POPRAWIONE")''',
        (doc_version_id,)
    ).fetchone()
    return c is not None


def _product_files_dir(product):
    """Zwraca ścieżkę folderu z plikami produktu (data/products/<klient>/<numer>)."""
    client = product['client_code'] or 'other'
    return os.path.join(DATA_DIR, client, product['number'])


def _user_has_history(db, user_id):
    """
    Sprawdza czy użytkownik ma jakiekolwiek powiązane rekordy w bazie.
    Jeśli tak – nie można go twardo skasować, trzeba anonimizować.
    """
    checks = [
        ('approvals', 'user_id'),
        ('files', 'uploaded_by'),
        ('products', 'created_by'),
        ('revisions', 'created_by'),
        ('doc_versions', 'created_by'),
        ('correction_requests', 'created_by'),
        ('generated_reports', 'created_by'),
        ('audit_log', 'user_id'),
    ]
    for table, column in checks:
        count = db.execute(
            f'SELECT COUNT(*) FROM {table} WHERE {column}=?', (user_id,)
        ).fetchone()[0]
        if count > 0:
            return True
    return False

# ── auth ──────────────────────────────────────────────────────────────────────

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE username=? AND is_active=1', (username,)).fetchone()
        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['full_name'] = user['full_name']
            session['role'] = user['role']
            log_event(db, user['id'], 'LOGIN', f'Zalogowano użytkownika {username}')
            db.commit()
            return redirect(url_for('dashboard'))
        flash('Nieprawidłowa nazwa użytkownika lub hasło.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    if 'user_id' in session:
        db = get_db()
        log_event(db, session['user_id'], 'LOGOUT', f'Wylogowano {session["username"]}')
        db.commit()
    session.clear()
    return redirect(url_for('login'))

# ── dashboard ─────────────────────────────────────────────────────────────────

@app.route('/')
@login_required
def dashboard():
    db = get_db()
    user_id = session['user_id']
    role = session['role']

    my_tasks = db.execute('''
        SELECT p.number, p.name, r.letter as revision, dv.version_num,
               rr.revision_id, dv.id as doc_version_id,
               p.id as product_id
        FROM required_roles rr
        JOIN revisions r ON r.id = rr.revision_id
        JOIN products p ON p.id = r.product_id
        JOIN doc_versions dv ON dv.revision_id = r.id AND dv.is_current = 1
        WHERE rr.role = ?
          AND r.status = 'ETAP_I'
          AND NOT EXISTS (
              SELECT 1 FROM approvals a
              WHERE a.doc_version_id = dv.id AND a.role = ? AND a.validity = 'WAZNA'
          )
    ''', (role, role)).fetchall()

    stage2_tasks = []
    if role == 'Kontrola jakości':
        stage2_tasks = db.execute('''
            SELECT p.number, p.name, r.letter as revision, dv.version_num,
                   r.id as revision_id, dv.id as doc_version_id, p.id as product_id
            FROM revisions r
            JOIN products p ON p.id = r.product_id
            JOIN doc_versions dv ON dv.revision_id = r.id AND dv.is_current = 1
            WHERE r.status = 'ETAP_II'
              AND NOT EXISTS (
                  SELECT 1 FROM approvals a
                  WHERE a.doc_version_id = dv.id AND a.role = 'Kontrola jakości'
                    AND a.stage = 2 AND a.validity = 'WAZNA'
              )
        ''').fetchall()

    recent = db.execute('''
        SELECT p.*, r.letter as current_revision, r.status as rev_status
        FROM products p
        LEFT JOIN revisions r ON r.product_id = p.id AND r.is_current = 1
        ORDER BY p.created_at DESC LIMIT 10
    ''').fetchall()

    stats = {
        'total_products': db.execute('SELECT COUNT(*) FROM products WHERE is_deleted=0').fetchone()[0],
        'active': db.execute("SELECT COUNT(*) FROM revisions WHERE status IN ('ETAP_I','ETAP_II')").fetchone()[0],
        'completed': db.execute("SELECT COUNT(*) FROM revisions WHERE status='ZAAKCEPTOWANY'").fetchone()[0],
        'my_tasks': len(my_tasks),
    }

    return render_template('dashboard.html', my_tasks=my_tasks, stage2_tasks=stage2_tasks,
                           recent=recent, stats=stats)

# ── help ──────────────────────────────────────────────────────────────────────

@app.route('/help')
@login_required
def help_page():
    """Strona pomocy – treść pochodzi z helps.HELP_SECTIONS."""
    return render_template('help.html', sections=helps.HELP_SECTIONS)

# ── products ──────────────────────────────────────────────────────────────────

@app.route('/products')
@login_required
def products():
    db = get_db()
    q = request.args.get('q', '').strip()
    status_filter = request.args.get('status', '')
    client_filter = request.args.get('client', '')

    query = '''
        SELECT p.*, r.letter as current_revision, r.status as rev_status
        FROM products p
        LEFT JOIN revisions r ON r.product_id = p.id AND r.is_current = 1
        WHERE p.is_deleted = 0
    '''
    params = []
    if q:
        query += ' AND (p.number LIKE ? OR p.name LIKE ? OR p.order_number LIKE ? OR p.description LIKE ?)'
        like = f'%{q}%'
        params += [like, like, like, like]
    if status_filter:
        query += ' AND r.status = ?'
        params.append(status_filter)
    if client_filter:
        query += ' AND p.client_code = ?'
        params.append(client_filter)
    query += ' ORDER BY p.created_at DESC'

    items = db.execute(query, params).fetchall()
    clients = db.execute('SELECT DISTINCT client_code FROM products WHERE is_deleted=0 ORDER BY client_code').fetchall()
    return render_template('products.html', items=items, q=q, status_filter=status_filter,
                           client_filter=client_filter, clients=clients)

@app.route('/products/new', methods=['GET', 'POST'])
@login_required
def product_new():
    if session['role'] not in ('Technolog', 'Administrator'):
        flash('Tylko Technolog lub Administrator może tworzyć nowe produkty.', 'danger')
        return redirect(url_for('products'))

    if request.method == 'POST':
        number = request.form['number'].strip().upper()
        name = request.form.get('name', '').strip()
        order_number = request.form.get('order_number', '').strip()
        description = request.form.get('description', '').strip()

        if not re.match(r'^\d{3}-\d{4}-\d{3}$', number):
            flash('Nieprawidłowy format numeru produktu (np. 063-1026-001).', 'danger')
            return render_template('product_form.html', title='Nowy produkt')

        db = get_db()
        existing = db.execute('SELECT id FROM products WHERE number=?', (number,)).fetchone()
        if existing:
            flash(f'Produkt {number} już istnieje.', 'danger')
            return render_template('product_form.html', title='Nowy produkt')

        client, period, seq = parse_product_number(number)
        pid = db.execute(
            'INSERT INTO products (number, name, order_number, description, client_code, created_by) VALUES (?,?,?,?,?,?)',
            (number, name, order_number, description, client, session['user_id'])
        ).lastrowid
        log_event(db, session['user_id'], 'PRODUKT_UTWORZONY', f'Utworzono produkt {number}', product_id=pid)
        db.commit()
        flash(f'Produkt {number} został utworzony.', 'success')
        return redirect(url_for('product_detail', product_id=pid))

    return render_template('product_form.html', title='Nowy produkt')

@app.route('/products/<int:product_id>')
@login_required
def product_detail(product_id):
    db = get_db()
    product = db.execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    if not product:
        abort(404)
    revisions = db.execute(
        'SELECT * FROM revisions WHERE product_id=? ORDER BY created_at DESC', (product_id,)
    ).fetchall()
    return render_template('product_detail.html', product=product, revisions=revisions)

# ── revisions ─────────────────────────────────────────────────────────────────

@app.route('/products/<int:product_id>/revisions/new', methods=['GET', 'POST'])
@login_required
def revision_new(product_id):
    if session['role'] not in ('Technolog', 'Administrator'):
        flash('Tylko Technolog lub Administrator może tworzyć rewizje.', 'danger')
        return redirect(url_for('product_detail', product_id=product_id))

    db = get_db()
    product = db.execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    if not product:
        abort(404)

    if request.method == 'POST':
        letter = request.form['letter'].strip().upper()
        notes = request.form.get('notes', '').strip()
        required_roles = request.form.getlist('required_roles')

        if not re.match(r'^R\d{2}$', letter):
            flash('Kod rewizji musi mieć format R + dwie cyfry (np. R01, R11).', 'danger')
            return render_template('revision_form.html', product=product, roles=ROLES, title='Nowa rewizja')

        existing = db.execute('SELECT id FROM revisions WHERE product_id=? AND letter=?', (product_id, letter)).fetchone()
        if existing:
            flash(f'Rewizja {letter} dla tego produktu już istnieje.', 'danger')
            return render_template('revision_form.html', product=product, roles=ROLES, title='Nowa rewizja')

        if not required_roles:
            flash('Wybierz co najmniej jedną wymaganą rolę.', 'danger')
            return render_template('revision_form.html', product=product, roles=ROLES, title='Nowa rewizja')

        db.execute('UPDATE revisions SET is_current=0 WHERE product_id=?', (product_id,))

        rid = db.execute(
            'INSERT INTO revisions (product_id, letter, notes, created_by, is_current) VALUES (?,?,?,?,1)',
            (product_id, letter, notes, session['user_id'])
        ).lastrowid

        for role in required_roles:
            if role in ROLES:
                db.execute('INSERT INTO required_roles (revision_id, role) VALUES (?,?)', (rid, role))

        dvid = db.execute(
            'INSERT INTO doc_versions (revision_id, version_num, created_by, is_current) VALUES (?,1,?,1)',
            (rid, session['user_id'])
        ).lastrowid

        log_event(db, session['user_id'], 'REWIZJA_UTWORZONA',
                  f'Utworzono rewizję {letter} dla produktu {product["number"]}',
                  product_id=product_id, revision_id=rid)
        log_event(db, session['user_id'], 'DOC_VERSION_UTWORZONA',
                  f'Utworzono dokumentację v1 dla rewizji {letter}',
                  product_id=product_id, revision_id=rid, doc_version_id=dvid)
        db.commit()
        flash(f'Rewizja {letter} została utworzona.', 'success')
        return redirect(url_for('revision_detail', product_id=product_id, revision_id=rid))

    return render_template('revision_form.html', product=product, roles=ROLES, title='Nowa rewizja')

@app.route('/products/<int:product_id>/revisions/<int:revision_id>')
@login_required
def revision_detail(product_id, revision_id):
    db = get_db()
    product = db.execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    revision = db.execute('SELECT * FROM revisions WHERE id=?', (revision_id,)).fetchone()
    if not product or not revision:
        abort(404)

    doc_versions = db.execute(
        'SELECT * FROM doc_versions WHERE revision_id=? ORDER BY version_num DESC', (revision_id,)
    ).fetchall()

    required_roles = db.execute(
        'SELECT role FROM required_roles WHERE revision_id=?', (revision_id,)
    ).fetchall()

    current_dv = db.execute(
        'SELECT * FROM doc_versions WHERE revision_id=? AND is_current=1', (revision_id,)
    ).fetchone()

    approvals = []
    corrections = []
    files = []
    if current_dv:
        approvals = db.execute(
            'SELECT a.*, u.full_name FROM approvals a JOIN users u ON u.id=a.user_id WHERE a.doc_version_id=? ORDER BY a.created_at',
            (current_dv['id'],)
        ).fetchall()
        corrections = db.execute(
            'SELECT cr.*, u.full_name FROM correction_requests cr JOIN users u ON u.id=cr.created_by WHERE cr.doc_version_id=? ORDER BY cr.created_at',
            (current_dv['id'],)
        ).fetchall()
        files = db.execute(
            'SELECT f.*, u.full_name as uploader FROM files f JOIN users u ON u.id=f.uploaded_by WHERE f.doc_version_id=? ORDER BY f.category, f.original_name',
            (current_dv['id'],)
        ).fetchall()

    history = db.execute(
        'SELECT al.*, u.full_name FROM audit_log al LEFT JOIN users u ON u.id=al.user_id WHERE al.revision_id=? ORDER BY al.created_at DESC LIMIT 50',
        (revision_id,)
    ).fetchall()

    role = session['role']
    user_approval = None
    if current_dv:
        user_approval = db.execute(
            'SELECT * FROM approvals WHERE doc_version_id=? AND user_id=? AND validity="WAZNA"',
            (current_dv['id'], session['user_id'])
        ).fetchone()

    stage1_complete = check_stage1_complete(db, revision_id, current_dv['id']) if current_dv else False
    has_open_corrections = check_open_corrections(db, current_dv['id']) if current_dv else False

    return render_template('revision_detail.html',
                           product=product, revision=revision, doc_versions=doc_versions,
                           required_roles=required_roles, current_dv=current_dv,
                           approvals=approvals, corrections=corrections, files=files,
                           history=history, role=role, user_approval=user_approval,
                           stage1_complete=stage1_complete, has_open_corrections=has_open_corrections,
                           FILE_CATEGORY_LABELS=FILE_CATEGORY_LABELS, ROLES=ROLES)

# ── files ─────────────────────────────────────────────────────────────────────

@app.route('/products/<int:product_id>/revisions/<int:revision_id>/upload', methods=['POST'])
@login_required
def upload_file(product_id, revision_id):
    db = get_db()
    product = db.execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    revision = db.execute('SELECT * FROM revisions WHERE id=?', (revision_id,)).fetchone()
    if not product or not revision:
        abort(404)

    if session['role'] not in ('Technolog', 'Administrator'):
        flash('Tylko Technolog lub Administrator może dodawać pliki.', 'danger')
        return redirect(url_for('revision_detail', product_id=product_id, revision_id=revision_id))

    if revision['status'] == 'ZAAKCEPTOWANY':
        flash('Nie można dodawać plików do zaakceptowanej rewizji.', 'danger')
        return redirect(url_for('revision_detail', product_id=product_id, revision_id=revision_id))

    current_dv = db.execute('SELECT * FROM doc_versions WHERE revision_id=? AND is_current=1', (revision_id,)).fetchone()
    if not current_dv:
        flash('Brak aktywnej wersji dokumentacji.', 'danger')
        return redirect(url_for('revision_detail', product_id=product_id, revision_id=revision_id))

    category = request.form.get('category', 'other')
    if category not in FILE_CATEGORIES:
        category = 'other'

    uploaded_files = request.files.getlist('files')
    if not uploaded_files:
        flash('Nie wybrano plików.', 'warning')
        return redirect(url_for('revision_detail', product_id=product_id, revision_id=revision_id))

    file_dir = get_file_dir(product['number'], revision['letter'], current_dv['version_num'], category)
    os.makedirs(file_dir, exist_ok=True)

    existing_count = db.execute(
        'SELECT COUNT(*) FROM files WHERE doc_version_id=? AND category=?',
        (current_dv['id'], category)
    ).fetchone()[0]

    for i, f in enumerate(uploaded_files):
        if f and f.filename and allowed_file(f.filename):
            orig_name = f.filename
            idx = existing_count + i + 1
            srv_name = server_filename(product['number'], revision['letter'],
                                       current_dv['version_num'], category, orig_name, idx)
            save_path = os.path.join(file_dir, srv_name)
            f.save(save_path)

            size = os.path.getsize(save_path)
            with open(save_path, 'rb') as fh:
                checksum = hashlib.sha256(fh.read()).hexdigest()

            db.execute('''INSERT INTO files
                (doc_version_id, original_name, server_name, server_path, category, size_bytes, checksum, uploaded_by)
                VALUES (?,?,?,?,?,?,?,?)''',
                (current_dv['id'], orig_name, srv_name, save_path, category, size, checksum, session['user_id']))
            log_event(db, session['user_id'], 'PLIK_DODANY',
                      f'Dodano plik {orig_name} ({category}) do v{current_dv["version_num"]}',
                      product_id=product_id, revision_id=revision_id, doc_version_id=current_dv['id'])

    db.commit()
    flash('Pliki zostały dodane.', 'success')
    return redirect(url_for('revision_detail', product_id=product_id, revision_id=revision_id))

@app.route('/files/<int:file_id>/download')
@login_required
def download_file(file_id):
    db = get_db()
    f = db.execute('SELECT * FROM files WHERE id=?', (file_id,)).fetchone()
    if not f:
        abort(404)
    return send_file(f['server_path'], as_attachment=True, download_name=f['original_name'])

# ── approvals ────────────────────────────────────────────────────────────────

@app.route('/products/<int:product_id>/revisions/<int:revision_id>/approve', methods=['POST'])
@login_required
def approve(product_id, revision_id):
    db = get_db()
    product = db.execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    revision = db.execute('SELECT * FROM revisions WHERE id=?', (revision_id,)).fetchone()
    if not product or not revision:
        abort(404)

    role = session['role']
    decision = request.form.get('decision')
    comment = request.form.get('comment', '').strip()
    stage = int(request.form.get('stage', 1))

    if decision not in ('AKCEPTUJE', 'WYMAGA_POPRAWY'):
        flash('Nieprawidłowa decyzja.', 'danger')
        return redirect(url_for('revision_detail', product_id=product_id, revision_id=revision_id))

    required = db.execute('SELECT id FROM required_roles WHERE revision_id=? AND role=?', (revision_id, role)).fetchone()
    if not required and role != 'Kontrola jakości':
        flash('Twoja rola nie jest wymagana dla tej rewizji.', 'danger')
        return redirect(url_for('revision_detail', product_id=product_id, revision_id=revision_id))

    current_dv = db.execute('SELECT * FROM doc_versions WHERE revision_id=? AND is_current=1', (revision_id,)).fetchone()
    if not current_dv:
        flash('Brak aktywnej wersji dokumentacji.', 'danger')
        return redirect(url_for('revision_detail', product_id=product_id, revision_id=revision_id))

    # Sprawdzamy, czy user już wydał ważną decyzję DLA TEGO SAMEGO ETAPU
    # tej samej wersji dokumentu. Bez rozróżnienia etapu KJ był blokowany
    # przy zatwierdzaniu Etapu II, jeśli wcześniej zaakceptował Etap I.
    existing = db.execute(
        '''SELECT id FROM approvals
           WHERE doc_version_id=? AND user_id=? AND role=? AND stage=? AND validity="WAZNA"''',
        (current_dv['id'], session['user_id'], role, stage)
    ).fetchone()
    if existing:
        flash('Już wydałeś ważną decyzję dla tego etapu tej wersji.', 'warning')
        return redirect(url_for('revision_detail', product_id=product_id, revision_id=revision_id))

    db.execute('''INSERT INTO approvals
        (doc_version_id, role, user_id, decision, comment, stage, validity)
        VALUES (?,?,?,?,?,?,"WAZNA")''',
        (current_dv['id'], role, session['user_id'], decision, comment, stage))

    action_label = 'zaakceptował' if decision == 'AKCEPTUJE' else 'zgłosił wymóg poprawy'
    stage_label = f'Etap {stage}' if stage else ''
    log_event(db, session['user_id'], 'DECYZJA',
              f'{session["full_name"]} ({role}) {action_label} {stage_label} v{current_dv["version_num"]}'.strip(),
              product_id=product_id, revision_id=revision_id, doc_version_id=current_dv['id'])

    if decision == 'WYMAGA_POPRAWY':
        problem_desc = request.form.get('problem_description', comment).strip()
        db.execute('''INSERT INTO correction_requests
            (doc_version_id, created_by, role, description, status)
            VALUES (?,?,?,?,"OTWARTE")''',
            (current_dv['id'], session['user_id'], role, problem_desc))
        log_event(db, session['user_id'], 'POPRAWKA_ZGLOSZONO',
                  f'Zgłoszono poprawkę do v{current_dv["version_num"]}',
                  product_id=product_id, revision_id=revision_id, doc_version_id=current_dv['id'])
    else:
        if stage == 1 and check_stage1_complete(db, revision_id, current_dv['id']):
            if not check_open_corrections(db, current_dv['id']):
                db.execute('UPDATE revisions SET status="ETAP_II" WHERE id=?', (revision_id,))
                log_event(db, session['user_id'], 'ETAP_I_ZAKOŃCZONY',
                          f'Etap I zakończony – rewizja {revision["letter"]} przechodzi do Etapu II',
                          product_id=product_id, revision_id=revision_id)
                flash('Etap I zakończony! Rewizja przechodzi do Kontroli Jakości (Etap II).', 'success')

        if stage == 2 and role == 'Kontrola jakości':
            db.execute('UPDATE revisions SET status="ZAAKCEPTOWANY", completed_at=? WHERE id=?',
                       (_utc_now_str(), revision_id))
            log_event(db, session['user_id'], 'REWIZJA_ZAAKCEPTOWANA',
                      f'Rewizja {revision["letter"]} produktu {product["number"]} zaakceptowana końcowo',
                      product_id=product_id, revision_id=revision_id)
            flash('Rewizja została ostatecznie zaakceptowana!', 'success')

    db.commit()
    flash(f'Decyzja "{decision}" została zapisana.', 'success')
    return redirect(url_for('revision_detail', product_id=product_id, revision_id=revision_id))

# ── new doc version (correction) ──────────────────────────────────────────────

@app.route('/products/<int:product_id>/revisions/<int:revision_id>/new_version', methods=['POST'])
@login_required
def new_doc_version(product_id, revision_id):
    if session['role'] not in ('Technolog', 'Administrator'):
        flash('Tylko Technolog lub Administrator może tworzyć nową wersję dokumentacji.', 'danger')
        return redirect(url_for('revision_detail', product_id=product_id, revision_id=revision_id))

    db = get_db()
    product = db.execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    revision = db.execute('SELECT * FROM revisions WHERE id=?', (revision_id,)).fetchone()
    if not product or not revision:
        abort(404)

    current_dv = db.execute('SELECT * FROM doc_versions WHERE revision_id=? AND is_current=1', (revision_id,)).fetchone()
    if not current_dv:
        abort(400)

    correction_request_id = request.form.get('correction_request_id')
    notes = request.form.get('notes', '').strip()

    db.execute('UPDATE doc_versions SET is_current=0 WHERE id=?', (current_dv['id'],))

    new_num = current_dv['version_num'] + 1
    new_dvid = db.execute(
        'INSERT INTO doc_versions (revision_id, version_num, created_by, is_current, notes) VALUES (?,?,?,1,?)',
        (revision_id, new_num, session['user_id'], notes)
    ).lastrowid

    db.execute(
        '''UPDATE approvals SET validity="UNIEWAZNIONA_PRZEZ_NOWA_WERSJE"
           WHERE doc_version_id=? AND stage=1''',
        (current_dv['id'],)
    )

    db.execute('UPDATE revisions SET status="ETAP_I" WHERE id=?', (revision_id,))

    if correction_request_id:
        db.execute(
            '''UPDATE correction_requests SET status="POPRAWIONE", resolved_by_version_id=?, closed_at=?
               WHERE id=?''',
            (new_dvid, _utc_now_str(), correction_request_id)
        )

    log_event(db, session['user_id'], 'DOC_VERSION_UTWORZONA',
              f'Utworzono dokumentację v{new_num} (poprz. v{current_dv["version_num"]} – akceptacje unieważnione)',
              product_id=product_id, revision_id=revision_id, doc_version_id=new_dvid)
    db.commit()
    flash(f'Dokumentacja v{new_num} została utworzona. Etap I zaczyna się od nowa.', 'success')
    return redirect(url_for('revision_detail', product_id=product_id, revision_id=revision_id))

# ── doc version history ───────────────────────────────────────────────────────

@app.route('/products/<int:product_id>/revisions/<int:revision_id>/versions/<int:dv_id>')
@login_required
def doc_version_detail(product_id, revision_id, dv_id):
    db = get_db()
    product = db.execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    revision = db.execute('SELECT * FROM revisions WHERE id=?', (revision_id,)).fetchone()
    dv = db.execute('SELECT * FROM doc_versions WHERE id=?', (dv_id,)).fetchone()
    if not product or not revision or not dv:
        abort(404)
    files = db.execute(
        'SELECT f.*, u.full_name as uploader FROM files f JOIN users u ON u.id=f.uploaded_by WHERE f.doc_version_id=? ORDER BY f.category, f.original_name',
        (dv_id,)
    ).fetchall()
    approvals = db.execute(
        'SELECT a.*, u.full_name FROM approvals a JOIN users u ON u.id=a.user_id WHERE a.doc_version_id=? ORDER BY a.created_at',
        (dv_id,)
    ).fetchall()
    corrections = db.execute(
        'SELECT cr.*, u.full_name FROM correction_requests cr JOIN users u ON u.id=cr.created_by WHERE cr.doc_version_id=? ORDER BY cr.created_at',
        (dv_id,)
    ).fetchall()
    return render_template('doc_version_detail.html', product=product, revision=revision, dv=dv,
                           files=files, approvals=approvals, corrections=corrections,
                           FILE_CATEGORY_LABELS=FILE_CATEGORY_LABELS)

# ── PDF report ────────────────────────────────────────────────────────────────

@app.route('/products/<int:product_id>/revisions/<int:revision_id>/report')
@login_required
def generate_report(product_id, revision_id):
    db = get_db()
    product = db.execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    revision = db.execute('SELECT * FROM revisions WHERE id=?', (revision_id,)).fetchone()
    if not product or not revision:
        abort(404)

    current_dv = db.execute('SELECT * FROM doc_versions WHERE revision_id=? AND is_current=1', (revision_id,)).fetchone()
    required_roles = db.execute('SELECT role FROM required_roles WHERE revision_id=?', (revision_id,)).fetchall()
    approvals = db.execute(
        'SELECT a.*, u.full_name FROM approvals a JOIN users u ON u.id=a.user_id WHERE a.doc_version_id=? AND a.validity="WAZNA" ORDER BY a.created_at',
        (current_dv['id'] if current_dv else 0,)
    ).fetchall()
    corrections = db.execute(
        'SELECT cr.*, u.full_name FROM correction_requests cr JOIN users u ON u.id=cr.created_by WHERE cr.doc_version_id=? ORDER BY cr.created_at',
        (current_dv['id'] if current_dv else 0,)
    ).fetchall()

    pdf_bytes = pdf_report.generate(product, revision, current_dv, required_roles, approvals, corrections)

    ts = datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')
    report_id = f"RPT-{product['number']}-REV{revision['letter']}-{ts}"
    db.execute('INSERT INTO generated_reports (revision_id, report_id, created_by) VALUES (?,?,?)',
               (revision_id, report_id, session['user_id']))
    log_event(db, session['user_id'], 'RAPORT_WYGENEROWANY',
              f'Wygenerowano kartę PDF {report_id}',
              product_id=product_id, revision_id=revision_id)
    db.commit()

    return send_file(io.BytesIO(pdf_bytes), mimetype='application/pdf',
                     as_attachment=True, download_name=f'{report_id}.pdf')

# ── admin ─────────────────────────────────────────────────────────────────────

@app.route('/admin/users')
@role_required('Administrator')
def admin_users():
    db = get_db()
    users = db.execute('SELECT * FROM users ORDER BY full_name').fetchall()
    return render_template('admin_users.html', users=users, roles=ROLES)

@app.route('/admin/users/new', methods=['GET', 'POST'])
@role_required('Administrator')
def admin_user_new():
    if request.method == 'POST':
        username = request.form['username'].strip()
        full_name = request.form['full_name'].strip()
        role = request.form['role']
        password = request.form['password']

        if role not in ROLES:
            flash('Nieprawidłowa rola.', 'danger')
            return render_template('admin_user_form.html', roles=ROLES, title='Nowy użytkownik')

        db = get_db()
        if db.execute('SELECT id FROM users WHERE username=?', (username,)).fetchone():
            flash('Nazwa użytkownika już istnieje.', 'danger')
            return render_template('admin_user_form.html', roles=ROLES, title='Nowy użytkownik')

        pw_hash = generate_password_hash(password)
        db.execute('INSERT INTO users (username, full_name, role, password_hash) VALUES (?,?,?,?)',
                   (username, full_name, role, pw_hash))
        log_event(db, session['user_id'], 'USER_UTWORZONY', f'Utworzono użytkownika {username}')
        db.commit()
        flash(f'Użytkownik {username} został utworzony.', 'success')
        return redirect(url_for('admin_users'))
    return render_template('admin_user_form.html', roles=ROLES, title='Nowy użytkownik')

@app.route('/admin/users/<int:user_id>/toggle', methods=['POST'])
@role_required('Administrator')
def admin_user_toggle(user_id):
    db = get_db()
    user = db.execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()
    if user:
        new_status = 0 if user['is_active'] else 1
        db.execute('UPDATE users SET is_active=? WHERE id=?', (new_status, user_id))
        log_event(db, session['user_id'], 'USER_STATUS',
                  f'Zmieniono status {user["username"]} na {"aktywny" if new_status else "nieaktywny"}')
        db.commit()
        flash('Status użytkownika zmieniony.', 'success')
    return redirect(url_for('admin_users'))

@app.route('/admin/users/<int:user_id>/reset_password', methods=['POST'])
@role_required('Administrator')
def admin_reset_password(user_id):
    new_password = request.form.get('new_password', '').strip()
    if len(new_password) < 6:
        flash('Hasło musi mieć co najmniej 6 znaków.', 'danger')
        return redirect(url_for('admin_users'))
    db = get_db()
    db.execute('UPDATE users SET password_hash=? WHERE id=?',
               (generate_password_hash(new_password), user_id))
    log_event(db, session['user_id'], 'HASLO_ZMIENIONE', f'Zresetowano hasło użytkownika ID={user_id}')
    db.commit()
    flash('Hasło zostało zmienione.', 'success')
    return redirect(url_for('admin_users'))

@app.route('/admin/users/<int:user_id>/delete', methods=['POST'])
@role_required('Administrator')
def admin_user_delete(user_id):
    """
    Usuwa użytkownika. Jeśli ma historię w systemie – anonimizuje konto
    (zachowuje wiersz w users, ale bez danych osobowych i bez możliwości logowania).
    Jeśli nie ma historii – kasuje trwale.
    """
    if user_id == session['user_id']:
        flash('Nie możesz usunąć własnego konta.', 'danger')
        return redirect(url_for('admin_users'))

    db = get_db()
    user = db.execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()
    if not user:
        abort(404)

    confirm = request.form.get('confirm_username', '').strip()
    if confirm != user['username']:
        flash('Nazwa użytkownika nie zgadza się z potwierdzeniem.', 'danger')
        return redirect(url_for('admin_users'))

    if user['role'] == 'Administrator' and user['is_active']:
        active_admins = db.execute(
            "SELECT COUNT(*) FROM users WHERE role='Administrator' AND is_active=1"
        ).fetchone()[0]
        if active_admins <= 1:
            flash('Nie można usunąć ostatniego aktywnego administratora.', 'danger')
            return redirect(url_for('admin_users'))

    has_history = _user_has_history(db, user_id)

    if not has_history:
        db.execute('DELETE FROM users WHERE id=?', (user_id,))
        log_event(db, session['user_id'], 'USER_USUNIETY',
                  f'Trwale usunięto konto {user["username"]} ({user["full_name"]}) – brak historii')
        db.commit()
        flash(f'Konto {user["username"]} zostało trwale usunięte.', 'success')
    else:
        anon_username = f'deleted_{user_id}'
        if db.execute('SELECT id FROM users WHERE username=?', (anon_username,)).fetchone():
            anon_username = f'deleted_{user_id}_{int(datetime.now(timezone.utc).timestamp())}'

        db.execute(
            '''UPDATE users SET username=?, full_name=?, is_active=0, password_hash='!'
               WHERE id=?''',
            (anon_username, '[użytkownik usunięty]', user_id)
        )
        log_event(db, session['user_id'], 'USER_ZANONIMIZOWANY',
                  f'Zanonimizowano konto {user["username"]} ({user["full_name"]}) – zachowano historię')
        db.commit()
        flash(f'Konto {user["username"]} zostało zanonimizowane (historia akceptacji zachowana).', 'success')

    return redirect(url_for('admin_users'))

@app.route('/admin/products/<int:product_id>/delete', methods=['POST'])
@role_required('Administrator')
def admin_product_delete(product_id):
    """
    Trwale usuwa produkt wraz z wszystkimi powiązanymi rekordami i plikami.
    Wpisy w audit_log zostają (traci się tylko powiązanie FK).
    Cała operacja na bazie w jednej transakcji – jeśli cokolwiek padnie, rollback.
    """
    db = get_db()
    product = db.execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    if not product:
        abort(404)

    confirm = request.form.get('confirm_number', '').strip()
    if confirm != product['number']:
        flash('Numer potwierdzenia nie zgadza się z numerem produktu.', 'danger')
        return redirect(url_for('product_detail', product_id=product_id))

    approved_count = db.execute(
        "SELECT COUNT(*) FROM revisions WHERE product_id=? AND status='ZAAKCEPTOWANY'",
        (product_id,)
    ).fetchone()[0]

    try:
        revision_ids = [r['id'] for r in db.execute(
            'SELECT id FROM revisions WHERE product_id=?', (product_id,)
        ).fetchall()]

        doc_version_ids = []
        if revision_ids:
            placeholders = ','.join('?' * len(revision_ids))
            doc_version_ids = [d['id'] for d in db.execute(
                f'SELECT id FROM doc_versions WHERE revision_id IN ({placeholders})',
                revision_ids
            ).fetchall()]

        if doc_version_ids:
            ph = ','.join('?' * len(doc_version_ids))
            db.execute(f'DELETE FROM correction_requests WHERE doc_version_id IN ({ph})', doc_version_ids)
            db.execute(f'DELETE FROM approvals WHERE doc_version_id IN ({ph})', doc_version_ids)
            db.execute(f'DELETE FROM files WHERE doc_version_id IN ({ph})', doc_version_ids)

        if revision_ids:
            ph = ','.join('?' * len(revision_ids))
            db.execute(f'DELETE FROM generated_reports WHERE revision_id IN ({ph})', revision_ids)
            db.execute(f'DELETE FROM doc_versions WHERE revision_id IN ({ph})', revision_ids)
            db.execute(f'DELETE FROM required_roles WHERE revision_id IN ({ph})', revision_ids)

        db.execute(
            'UPDATE audit_log SET product_id=NULL, revision_id=NULL, doc_version_id=NULL WHERE product_id=?',
            (product_id,)
        )

        db.execute('DELETE FROM revisions WHERE product_id=?', (product_id,))
        db.execute('DELETE FROM products WHERE id=?', (product_id,))

        note = ' (miał zaakceptowane rewizje)' if approved_count else ''
        log_event(db, session['user_id'], 'PRODUKT_USUNIETY',
                  f'Trwale usunięto produkt {product["number"]}'
                  f'{(" – " + product["name"]) if product["name"] else ""}{note}')

        db.commit()
    except Exception as e:
        db.rollback()
        flash(f'Błąd podczas usuwania produktu: {e}', 'danger')
        return redirect(url_for('product_detail', product_id=product_id))

    files_dir = _product_files_dir(product)
    if os.path.isdir(files_dir):
        try:
            shutil.rmtree(files_dir)
        except Exception as e:
            flash(f'Produkt usunięty z bazy, ale nie udało się usunąć plików: {e}', 'warning')

    flash(f'Produkt {product["number"]} został trwale usunięty.', 'success')
    return redirect(url_for('products'))

@app.route('/admin/log')
@role_required('Administrator')
def admin_log():
    db = get_db()
    page = int(request.args.get('page', 1))
    per_page = 50
    offset = (page - 1) * per_page
    logs = db.execute(
        'SELECT al.*, u.full_name FROM audit_log al LEFT JOIN users u ON u.id=al.user_id ORDER BY al.created_at DESC LIMIT ? OFFSET ?',
        (per_page, offset)
    ).fetchall()
    total = db.execute('SELECT COUNT(*) FROM audit_log').fetchone()[0]
    return render_template('admin_log.html', logs=logs, page=page, per_page=per_page, total=total)

# ── profile ───────────────────────────────────────────────────────────────────

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    db = get_db()
    if request.method == 'POST':
        current_pw = request.form.get('current_password', '')
        new_pw = request.form.get('new_password', '').strip()
        user = db.execute('SELECT * FROM users WHERE id=?', (session['user_id'],)).fetchone()
        if not check_password_hash(user['password_hash'], current_pw):
            flash('Nieprawidłowe aktualne hasło.', 'danger')
        elif len(new_pw) < 6:
            flash('Nowe hasło musi mieć co najmniej 6 znaków.', 'danger')
        else:
            db.execute('UPDATE users SET password_hash=? WHERE id=?',
                       (generate_password_hash(new_pw), session['user_id']))
            log_event(db, session['user_id'], 'HASLO_ZMIENIONE', 'Użytkownik zmienił własne hasło')
            db.commit()
            flash('Hasło zostało zmienione.', 'success')
    user = db.execute('SELECT * FROM users WHERE id=?', (session['user_id'],)).fetchone()
    return render_template('profile.html', user=user)

# ── API ───────────────────────────────────────────────────────────────────────

@app.route('/api/search')
@login_required
def api_search():
    q = request.args.get('q', '').strip()
    if len(q) < 2:
        return jsonify([])
    db = get_db()
    results = db.execute('''
        SELECT p.id, p.number, p.name, r.letter, r.status
        FROM products p
        LEFT JOIN revisions r ON r.product_id = p.id AND r.is_current = 1
        WHERE p.is_deleted=0 AND (p.number LIKE ? OR p.name LIKE ? OR p.order_number LIKE ?)
        ORDER BY p.number LIMIT 10
    ''', (f'%{q}%', f'%{q}%', f'%{q}%')).fetchall()
    return jsonify([dict(r) for r in results])

# ── init ──────────────────────────────────────────────────────────────────────

@app.teardown_appcontext
def close_db(error):
    db = g.pop('db', None)
    if db is not None:
        db.close()

if __name__ == '__main__':
    with app.app_context():
        init_db()
    app.run(host='0.0.0.0', port=5011, debug=True)