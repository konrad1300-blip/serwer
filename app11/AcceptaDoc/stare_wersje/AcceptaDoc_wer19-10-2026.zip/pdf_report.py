"""PDF report generator using ReportLab."""
from io import BytesIO
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                  TableStyle, HRFlowable)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import os


def _safe(text):
    if text is None:
        return '-'
    return str(text)


def generate(product, revision, current_dv, required_roles, approvals, corrections):
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4,
                            leftMargin=20*mm, rightMargin=20*mm,
                            topMargin=20*mm, bottomMargin=20*mm)

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle('Title', parent=styles['Heading1'],
                                  fontSize=16, spaceAfter=6, textColor=colors.HexColor('#1a2744'))
    subtitle_style = ParagraphStyle('Subtitle', parent=styles['Normal'],
                                     fontSize=9, textColor=colors.grey)
    heading_style = ParagraphStyle('Heading', parent=styles['Heading2'],
                                    fontSize=11, spaceBefore=10, spaceAfter=4,
                                    textColor=colors.HexColor('#1a2744'))
    normal = styles['Normal']
    normal.fontSize = 9

    story = []

    # Header
    report_id = f"RPT-{product['number']}-REV{_safe(revision['letter'])}-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
    story.append(Paragraph('KARTA AKCEPTACJI DOKUMENTACJI', title_style))
    story.append(Paragraph(f'Identyfikator raportu: {report_id}', subtitle_style))
    story.append(HRFlowable(width='100%', thickness=2, color=colors.HexColor('#1a2744')))
    story.append(Spacer(1, 4*mm))

    # Product info table
    info_data = [
        ['Numer produktu', _safe(product['number']), 'Rewizja', _safe(revision['letter'])],
        ['Nazwa produktu', _safe(product['name']), 'Status', _safe(revision['status'])],
        ['Numer zamówienia', _safe(product['order_number']), 'Wersja dok.',
         f"v{_safe(current_dv['version_num'])}" if current_dv else '-'],
        ['Kod klienta', _safe(product['client_code']), 'Data raportu',
         datetime.utcnow().strftime('%d.%m.%Y %H:%M')],
    ]
    info_table = Table(info_data, colWidths=[45*mm, 65*mm, 30*mm, 35*mm])
    info_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#eef2ff')),
        ('BACKGROUND', (2, 0), (2, -1), colors.HexColor('#eef2ff')),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTNAME', (2, 0), (2, -1), 'Helvetica-Bold'),
        ('BOX', (0, 0), (-1, -1), 0.5, colors.grey),
        ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.lightgrey),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('PADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 4*mm))

    # Required roles
    story.append(Paragraph('Wymagane role', heading_style))
    req_roles = [r['role'] for r in required_roles]
    roles_data = [['Rola', 'Wymagana']]
    all_roles = ['Technolog', 'Konstruktor', 'Produkcja - elementy', 'Produkcja - szycie',
                 'Produkcja - zgrzewanie', 'Kontrola jakości']
    for role in all_roles:
        roles_data.append([role, '✓ Wymagana' if role in req_roles else '— Niewymagana'])
    roles_table = Table(roles_data, colWidths=[100*mm, 75*mm])
    roles_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a2744')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f9ff')]),
        ('BOX', (0, 0), (-1, -1), 0.5, colors.grey),
        ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.lightgrey),
        ('PADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(roles_table)
    story.append(Spacer(1, 4*mm))

    # Approvals
    story.append(Paragraph('Decyzje akceptacji', heading_style))
    if approvals:
        appr_data = [['Rola', 'Osoba', 'Decyzja', 'Data', 'Ważność', 'Komentarz']]
        for a in approvals:
            decision_label = '✓ Akceptuję' if a['decision'] == 'AKCEPTUJE' else '✗ Wymaga poprawy'
            validity = 'Ważna' if a['validity'] == 'WAZNA' else 'Unieważniona'
            date_str = a['created_at'][:16] if a['created_at'] else '-'
            appr_data.append([
                _safe(a['role']),
                _safe(a['full_name']),
                decision_label,
                date_str,
                validity,
                _safe(a['comment'])[:40] if a['comment'] else ''
            ])
        appr_table = Table(appr_data, colWidths=[38*mm, 32*mm, 30*mm, 28*mm, 22*mm, 25*mm])
        appr_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a2744')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f9ff')]),
            ('BOX', (0, 0), (-1, -1), 0.5, colors.grey),
            ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.lightgrey),
            ('PADDING', (0, 0), (-1, -1), 3),
            ('WORDWRAP', (0, 0), (-1, -1), True),
        ]))
        story.append(appr_table)
    else:
        story.append(Paragraph('Brak decyzji akceptacji.', normal))
    story.append(Spacer(1, 4*mm))

    # Corrections
    if corrections:
        story.append(Paragraph('Zgłoszenia poprawek', heading_style))
        corr_data = [['#', 'Zgłaszający', 'Rola', 'Opis', 'Status', 'Data']]
        for i, c in enumerate(corrections, 1):
            date_str = c['created_at'][:16] if c['created_at'] else '-'
            corr_data.append([
                str(i),
                _safe(c['full_name']),
                _safe(c['role']),
                _safe(c['description'])[:50],
                _safe(c['status']),
                date_str
            ])
        corr_table = Table(corr_data, colWidths=[10*mm, 32*mm, 30*mm, 55*mm, 25*mm, 23*mm])
        corr_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#b91c1c')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#fff5f5')]),
            ('BOX', (0, 0), (-1, -1), 0.5, colors.grey),
            ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.lightgrey),
            ('PADDING', (0, 0), (-1, -1), 3),
        ]))
        story.append(corr_table)

    # Footer
    story.append(Spacer(1, 8*mm))
    story.append(HRFlowable(width='100%', thickness=1, color=colors.grey))
    story.append(Paragraph(
        f'Raport wygenerowany automatycznie przez system Zatwierdzenia | {datetime.utcnow().strftime("%d.%m.%Y %H:%M")} UTC',
        subtitle_style
    ))

    doc.build(story)
    return buf.getvalue()
