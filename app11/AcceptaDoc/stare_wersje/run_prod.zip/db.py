import sqlite3
import os
from datetime import datetime
from flask import g

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'instance', 'zatwierdzenia.db')


def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA foreign_keys = ON')
        g.db.execute('PRAGMA journal_mode = WAL')
    return g.db


def log_event(db, user_id, event_type, description, product_id=None, revision_id=None, doc_version_id=None):
    db.execute(
        '''INSERT INTO audit_log (user_id, event_type, description, product_id, revision_id, doc_version_id)
           VALUES (?,?,?,?,?,?)''',
        (user_id, event_type, description, product_id, revision_id, doc_version_id)
    )


SCHEMA = '''
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT UNIQUE NOT NULL,
    full_name     TEXT NOT NULL,
    role          TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    is_active     INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS products (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    number       TEXT UNIQUE NOT NULL,
    name         TEXT,
    order_number TEXT,
    description  TEXT,
    client_code  TEXT,
    is_deleted   INTEGER NOT NULL DEFAULT 0,
    created_by   INTEGER REFERENCES users(id),
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Uwaga: kolumna `letter` przechowuje kod rewizji (R01, R02, … R99),
-- mimo że historyczna nazwa sugeruje pojedynczą literę.
CREATE TABLE IF NOT EXISTS revisions (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id   INTEGER NOT NULL REFERENCES products(id),
    letter       TEXT NOT NULL,
    notes        TEXT,
    status       TEXT NOT NULL DEFAULT 'ETAP_I',
    is_current   INTEGER NOT NULL DEFAULT 0,
    created_by   INTEGER REFERENCES users(id),
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    completed_at TEXT,
    UNIQUE(product_id, letter)
);

CREATE TABLE IF NOT EXISTS required_roles (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    revision_id INTEGER NOT NULL REFERENCES revisions(id),
    role        TEXT NOT NULL,
    UNIQUE(revision_id, role)
);

CREATE TABLE IF NOT EXISTS doc_versions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    revision_id INTEGER NOT NULL REFERENCES revisions(id),
    version_num INTEGER NOT NULL,
    notes       TEXT,
    is_current  INTEGER NOT NULL DEFAULT 0,
    created_by  INTEGER REFERENCES users(id),
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE(revision_id, version_num)
);

CREATE TABLE IF NOT EXISTS files (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_version_id INTEGER NOT NULL REFERENCES doc_versions(id),
    original_name TEXT NOT NULL,
    server_name   TEXT NOT NULL,
    server_path   TEXT NOT NULL,
    category      TEXT NOT NULL DEFAULT 'other',
    size_bytes    INTEGER,
    checksum      TEXT,
    is_deleted    INTEGER NOT NULL DEFAULT 0,
    uploaded_by   INTEGER REFERENCES users(id),
    uploaded_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS approvals (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_version_id  INTEGER NOT NULL REFERENCES doc_versions(id),
    role            TEXT NOT NULL,
    user_id         INTEGER NOT NULL REFERENCES users(id),
    decision        TEXT NOT NULL,
    comment         TEXT,
    stage           INTEGER NOT NULL DEFAULT 1,
    validity        TEXT NOT NULL DEFAULT 'WAZNA',
    invalidation_reason TEXT,
    created_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS correction_requests (
    id                     INTEGER PRIMARY KEY AUTOINCREMENT,
    doc_version_id         INTEGER NOT NULL REFERENCES doc_versions(id),
    created_by             INTEGER NOT NULL REFERENCES users(id),
    role                   TEXT NOT NULL,
    description            TEXT NOT NULL,
    status                 TEXT NOT NULL DEFAULT 'OTWARTE',
    resolved_by_version_id INTEGER REFERENCES doc_versions(id),
    closed_at              TEXT,
    created_at             TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_log (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id        INTEGER REFERENCES users(id),
    event_type     TEXT NOT NULL,
    description    TEXT NOT NULL,
    product_id     INTEGER REFERENCES products(id),
    revision_id    INTEGER REFERENCES revisions(id),
    doc_version_id INTEGER REFERENCES doc_versions(id),
    created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS generated_reports (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    revision_id INTEGER NOT NULL REFERENCES revisions(id),
    report_id   TEXT NOT NULL,
    created_by  INTEGER REFERENCES users(id),
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
'''


def _migrate_letter_to_code(conn):
    """
    Jednorazowa migracja starych literowych rewizji (A, B, C…) na format R01, R02, R03…
    Bezpieczna do wielokrotnego wywołania – po konwersji nie ma już rewizji o długości 1.
    Zwraca liczbę zmigrowanych rekordów.
    """
    rows = conn.execute(
        "SELECT id, letter FROM revisions WHERE length(letter) = 1"
    ).fetchall()
    if not rows:
        return 0
    for row in rows:
        num = ord(row['letter'].upper()) - ord('A') + 1
        new_code = f"R{num:02d}"
        conn.execute("UPDATE revisions SET letter=? WHERE id=?", (new_code, row['id']))
    conn.commit()
    return len(rows)


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)

    # Migracja formatu rewizji: A → R01, B → R02, …
    migrated = _migrate_letter_to_code(conn)
    if migrated:
        print(f'[db] Zmigrowano {migrated} rewizji z formatu literowego na Rxx.')

    # Create default admin if no users exist
    existing = conn.execute('SELECT COUNT(*) FROM users').fetchone()[0]
    if existing == 0:
        from werkzeug.security import generate_password_hash
        conn.execute(
            'INSERT INTO users (username, full_name, role, password_hash) VALUES (?,?,?,?)',
            ('admin', 'Administrator systemu', 'Administrator', generate_password_hash('admin123'))
        )
        # Demo users
        demo_users = [
            ('technolog1', 'Anna Nowak', 'Technolog', 'haslo123'),
            ('konstruktor1', 'Jan Kowalski', 'Konstruktor', 'haslo123'),
            ('produkcja_el', 'Marek Wiśniewski', 'Produkcja - elementy', 'haslo123'),
            ('produkcja_sz', 'Katarzyna Zając', 'Produkcja - szycie', 'haslo123'),
            ('kj1', 'Piotr Dąbrowski', 'Kontrola jakości', 'haslo123'),
        ]
        for uname, fname, role, pw in demo_users:
            conn.execute(
                'INSERT INTO users (username, full_name, role, password_hash) VALUES (?,?,?,?)',
                (uname, fname, role, generate_password_hash(pw))
            )
        conn.commit()
    conn.close()