"""
Generator karty akceptacji PDF.

Wymagania:
  - Polskie znaki diakrytyczne → czcionka TTF z katalogu `fonts/`
    (preferowane: DejaVuSans.ttf + DejaVuSans-Bold.ttf,
     fallback:   arial.ttf + arialbd.ttf).
  - Logo firmy w nagłówku, rysowane na każdej stronie – plik `fonts/logo_hansa.png`.
  - Strefa czasu: Europe/Warsaw (niezależnie od TZ serwera).
  - Układ sformalizowany: nagłówek z logo + tytułem, banner z numerem produktu,
    werdykt w ramce, tabela ról i decyzji, zawartość dokumentacji.
"""
from io import BytesIO
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import os

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                 TableStyle)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FONTS_DIR = os.path.join(BASE_DIR, 'fonts')
LOGO_PATH = os.path.join(FONTS_DIR, 'logo_hansa.png')
LOCAL_TZ = ZoneInfo('Europe/Warsaw')

# Fallback – gdyby wywołujący nie przekazał `category_labels`.
_DEFAULT_CATEGORY_LABELS = {
    'documents': 'Dokumentacja główna',
    'bom': 'BOM (lista materiałów)',
    'drawings': 'Rysunki techniczne',
    'prototype_photos': 'Zdjęcia prototypu',
    'other': 'Inne',
}


# ── Rejestracja czcionek ─────────────────────────────────────────────────────

def _register_fonts():
    """
    Rejestruje w ReportLabie czcionkę regularną i bold z polskimi glifami.

    Kolejność prób – regular:  DejaVuSans.ttf → arial.ttf
                        bold:    DejaVuSans-Bold.ttf → arialbd.ttf
    Brak bold = fallback na regular (nagłówki będą „płaskie", ale czytelne).

    Rzuca RuntimeError, jeśli nie znaleziono żadnej czcionki regularnej
    – wolimy fail-fast przy imporcie niż krzaczki na wygenerowanym PDF.
    """
    regular_candidates = [
        ('DejaVuSans.ttf', 'AppFont'),
        ('arial.ttf',      'AppFont'),
    ]
    bold_candidates = [
        ('DejaVuSans-Bold.ttf', 'AppFont-Bold'),
        ('arialbd.ttf',         'AppFont-Bold'),
    ]

    def _try(candidates):
        for filename, name in candidates:
            path = os.path.join(FONTS_DIR, filename)
            if not os.path.isfile(path):
                continue
            try:
                pdfmetrics.registerFont(TTFont(name, path))
                return name
            except Exception as exc:
                print(f'[pdf_report] Nie udało się zarejestrować {path}: {exc}')
        return None

    regular = _try(regular_candidates)
    if regular is None:
        raise RuntimeError(
            f'Brak pliku czcionki w {FONTS_DIR}. '
            f'Oczekiwano jednego z: {[f for f, _ in regular_candidates]}'
        )
    bold = _try(bold_candidates) or regular

    # Rodzina '<rodzina>' z mapowaniem <b>/<i>/<b><i> używanym w Paragraph.
    pdfmetrics.registerFontFamily(
        'AppFont',
        normal=regular,
        bold=bold,
        italic=regular,
        boldItalic=bold,
    )
    return regular, bold


FONT_REGULAR, FONT_BOLD = _register_fonts()


# ── Logo ─────────────────────────────────────────────────────────────────────

_LOGO_READER = None
_LOGO_SIZE = None
_LOGO_LOAD_ATTEMPTED = False


def _load_logo():
    """
    Leniwe wczytanie logo z `fonts/logo_hansa.png`.

    Zwraca (ImageReader, (w, h)) przy sukcesie albo (None, None) przy braku pliku.
    Próbę wczytania podejmujemy tylko raz na proces – kolejne wywołania
    (kolejne strony PDF) korzystają z cache'u, żeby nie spamować logów.
    """
    global _LOGO_READER, _LOGO_SIZE, _LOGO_LOAD_ATTEMPTED
    if _LOGO_LOAD_ATTEMPTED:
        return _LOGO_READER, _LOGO_SIZE
    _LOGO_LOAD_ATTEMPTED = True

    if not os.path.isfile(LOGO_PATH):
        print(f'[pdf_report] Logo nie znalezione: {LOGO_PATH} — nagłówek bez logo.')
        return None, None

    try:
        _LOGO_READER = ImageReader(LOGO_PATH)
        _LOGO_SIZE = _LOGO_READER.getSize()
        print(f'[pdf_report] Logo wczytane: {LOGO_PATH} '
              f'({_LOGO_SIZE[0]}×{_LOGO_SIZE[1]} px)')
        return _LOGO_READER, _LOGO_SIZE
    except Exception as exc:
        print(f'[pdf_report] Nie udało się wczytać logo {LOGO_PATH}: {exc}')
        return None, None


# ── Helpers ──────────────────────────────────────────────────────────────────

def _now_local():
    """Aktualny czas w strefie Europe/Warsaw (niezależny od TZ serwera)."""
    return datetime.now(LOCAL_TZ)


def _to_local(value):
    """
    Konwertuje timestamp SQLite ('YYYY-MM-DD HH:MM:SS', UTC) na lokalny
    'DD.MM.YYYY HH:MM'. Wartości spoza formatu przepuszcza bez zmian.
    """
    if value is None or value == '':
        return '—'
    try:
        s = str(value).strip().replace('Z', '+00:00')
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(LOCAL_TZ).strftime('%d.%m.%Y %H:%M')
    except (ValueError, AttributeError):
        return str(value)


def _safe(value, dash='—'):
    """Bezpieczna reprezentacja wartości – None/pusty string → myślnik."""
    if value is None:
        return dash
    s = str(value).strip()
    return s if s else dash


def _to_dict(obj):
    """sqlite3.Row lub dict → dict (bezpiecznie dla None)."""
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return obj
    try:
        return dict(obj)
    except (TypeError, ValueError):
        return {}


def _compute_verdict(revision_status, required_roles, approvals, corrections):
    """
    Zwraca słownik z etykietą, kluczem koloru (success/warning/danger)
    i opisem – dla ramki werdyktu w sekcji 2.
    """
    revision_status = (revision_status or '').upper()
    required = {r['role'] for r in required_roles}
    total = len(required)

    stage1_valid = [a for a in approvals
                    if a.get('stage', 1) == 1 and a.get('validity') == 'WAZNA']
    stage1_accepted = {a['role'] for a in stage1_valid if a['decision'] == 'AKCEPTUJE'}
    stage1_rejected = any(a['decision'] == 'WYMAGA_POPRAWY' for a in stage1_valid)
    accepted_count = len(required & stage1_accepted)

    open_corrections = [c for c in corrections
                        if c.get('status') not in ('ZAMKNIETE', 'POPRAWIONE')]

    if revision_status == 'ZAAKCEPTOWANY':
        return {
            'label': 'ZAAKCEPTOWANA',
            'color': 'success',
            'desc': 'Dokumentacja zatwierdzona końcowo przez Kontrolę jakości. '
                    'Produkt może wejść do produkcji seryjnej.',
        }
    if revision_status == 'ETAP_II':
        return {
            'label': 'W TOKU — ETAP II',
            'color': 'warning',
            'desc': 'Etap I zakończony. Oczekuje na kontrolę jakości pierwszej sztuki.',
        }
    if stage1_rejected or open_corrections:
        return {
            'label': 'WYMAGA POPRAWEK',
            'color': 'danger',
            'desc': f'Zgłoszono uwagi wymagające poprawy. '
                    f'Zaakceptowano {accepted_count}/{total} wymaganych ról w Etapie I.',
        }
    if total > 0 and accepted_count == total:
        return {
            'label': 'ETAP I ZAKOŃCZONY',
            'color': 'warning',
            'desc': f'Wszystkie {total} wymaganych ról zaakceptowało. '
                    'Oczekuje na przejście do Etapu II.',
        }
    return {
        'label': 'W TOKU — ETAP I',
        'color': 'warning',
        'desc': f'Trwa zbieranie akceptacji Etapu I: {accepted_count}/{total} '
                f'wymaganych ról.',
    }


# ── Generator ────────────────────────────────────────────────────────────────

def generate(product, revision, current_dv, required_roles, approvals, corrections,
             files=None, category_labels=None, report_id=None):
    """
    Buduje sformalizowaną kartę akceptacji PDF.

    Parametry:
      product, revision     – słowniki/sqlite3.Row z bazy
      current_dv            – bieżąca wersja dokumentacji (może być None)
      required_roles        – lista {'role': ...}
      approvals             – lista akceptacji (z JOIN na users – pole full_name)
      corrections           – lista zgłoszeń poprawek
      files                 – opcjonalna lista plików (tylko pole 'category')
      category_labels       – mapa kategorii → etykiety (jeśli None, użyje domyślnych)
      report_id             – jeśli None, generowany lokalnie (YYYYMMDDHHMMSS)

    Zwraca bajty PDF.
    """
    # Ujednolicamy typ danych wejściowych (sqlite3.Row / dict / None)
    product       = _to_dict(product)
    revision      = _to_dict(revision)
    current_dv    = _to_dict(current_dv) if current_dv is not None else None
    required_roles = [_to_dict(r) for r in (required_roles or [])]
    approvals      = [_to_dict(a) for a in (approvals or [])]
    corrections    = [_to_dict(c) for c in (corrections or [])]
    files          = [_to_dict(f) for f in (files or [])]
    labels         = category_labels or _DEFAULT_CATEGORY_LABELS

    generated_at = _now_local()
    if not report_id:
        ts = generated_at.strftime('%Y%m%d%H%M%S')
        report_id = f"RPT-{product.get('number', '?')}-REV{revision.get('letter', '?')}-{ts}"

    buf = BytesIO()
    doc = SimpleDocTemplate(
        buf, pagesize=A4,
        leftMargin=18*mm, rightMargin=18*mm,
        # Zwiększony topMargin – miejsce na nagłówek z logo (rysowany w callbacku).
        topMargin=36*mm, bottomMargin=20*mm,
    )
    doc_width = doc.width

    # ── Paleta ──────────────────────────────────────────────────────────
    navy       = colors.HexColor('#1a2744')
    indigo     = colors.HexColor('#4f52c7')
    light_bg   = colors.HexColor('#eef2ff')
    grey       = colors.HexColor('#6b7280')
    light_grey = colors.HexColor('#e5e7eb')
    text_col   = colors.HexColor('#111827')

    verdict_palette = {
        'success': (colors.HexColor('#d1fae5'), colors.HexColor('#065f46')),
        'warning': (colors.HexColor('#fef3c7'), colors.HexColor('#92400e')),
        'danger':  (colors.HexColor('#fee2e2'), colors.HexColor('#991b1b')),
    }

    # ── Style ───────────────────────────────────────────────────────────
    styles = getSampleStyleSheet()

    # title_style i sig_head_style usunięte – tytuł rysuje callback nagłówka,
    # sekcja podpisów została wykasowana.
    product_num_style = ParagraphStyle(
        'ProductNum', fontName=FONT_BOLD, fontSize=18, leading=22,
        textColor=colors.white, alignment=TA_CENTER)
    subtitle_style = ParagraphStyle(
        'Subtitle', fontName=FONT_REGULAR, fontSize=10, leading=13,
        textColor=navy, alignment=TA_CENTER)
    meta_style = ParagraphStyle(
        'Meta', fontName=FONT_REGULAR, fontSize=8.5, leading=11,
        textColor=grey, alignment=TA_CENTER)
    section_style = ParagraphStyle(
        'Section', fontName=FONT_BOLD, fontSize=11, leading=14,
        textColor=navy, spaceBefore=10, spaceAfter=4, keepWithNext=True)
    cell_label_style = ParagraphStyle(
        'CellLabel', fontName=FONT_BOLD, fontSize=8.5, leading=11, textColor=navy)
    cell_style = ParagraphStyle(
        'Cell', fontName=FONT_REGULAR, fontSize=8.5, leading=11, textColor=text_col)
    cell_muted_style = ParagraphStyle(
        'CellMuted', fontName=FONT_REGULAR, fontSize=8.5, leading=11, textColor=grey)
    th_style = ParagraphStyle(
        'TH', fontName=FONT_BOLD, fontSize=8.5, leading=11, textColor=colors.white)
    verdict_label_style = ParagraphStyle(
        'VerdictLabel', fontName=FONT_BOLD, fontSize=13, leading=16)
    verdict_desc_style = ParagraphStyle(
        'VerdictDesc', fontName=FONT_REGULAR, fontSize=9, leading=12, textColor=text_col)

    story = []

    # ── Banner z numerem produktu ───────────────────────────────────────
    # Nagłówek (logo + tytuł + linia) rysuje _draw_header_footer() – na każdej stronie.
    banner = Table(
        [[Paragraph(_safe(product.get('number')), product_num_style)]],
        colWidths=[doc_width])
    banner.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), indigo),
        ('PADDING', (0, 0), (-1, -1), 10),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]))
    story.append(banner)
    story.append(Spacer(1, 5))

    # Podtytuł: nazwa · rewizja · wersja
    subtitle_parts = []
    if product.get('name'):
        subtitle_parts.append(_safe(product['name']))
    if revision.get('letter'):
        subtitle_parts.append(f'Rewizja {revision["letter"]}')
    if current_dv and current_dv.get('version_num'):
        subtitle_parts.append(f'v{int(current_dv["version_num"]):03d}')
    if subtitle_parts:
        story.append(Paragraph('  ·  '.join(subtitle_parts), subtitle_style))
        story.append(Spacer(1, 3))

    # Meta: ID raportu + czas lokalny
    meta_text = (f'Raport: {report_id} &nbsp;&nbsp;|&nbsp;&nbsp; '
                 f'Wygenerowano: {generated_at.strftime("%d.%m.%Y %H:%M")} '
                 f'(Europe/Warsaw)')
    story.append(Paragraph(meta_text, meta_style))
    story.append(Spacer(1, 10))

    # ── 1. Informacje o produkcie ───────────────────────────────────────
    story.append(Paragraph('1. INFORMACJE O PRODUKCIE', section_style))
    info_rows = [
        [Paragraph('Nazwa produktu', cell_label_style),
         Paragraph(_safe(product.get('name')), cell_style)],
        [Paragraph('Opis', cell_label_style),
         Paragraph(_safe(product.get('description')), cell_style)],
        [Paragraph('Kod klienta', cell_label_style),
         Paragraph(_safe(product.get('client_code')), cell_style)],
        [Paragraph('Numer zamówienia', cell_label_style),
         Paragraph(_safe(product.get('order_number')), cell_style)],
        [Paragraph('Data utworzenia produktu', cell_label_style),
         Paragraph(_to_local(product.get('created_at')), cell_style)],
        [Paragraph('Rewizja', cell_label_style),
         Paragraph(f'{_safe(revision.get("letter"))} '
                   f'<font color="#6b7280">({_safe(revision.get("status"))})</font>',
                   cell_style)],
        [Paragraph('Notatki rewizji', cell_label_style),
         Paragraph(_safe(revision.get('notes')), cell_style)],
    ]
    if current_dv:
        info_rows.append([
            Paragraph('Wersja dokumentacji', cell_label_style),
            Paragraph(f'v{int(current_dv.get("version_num", 0)):03d}', cell_style),
        ])
        info_rows.append([
            Paragraph('Data utworzenia wersji', cell_label_style),
            Paragraph(_to_local(current_dv.get('created_at')), cell_style),
        ])
        if current_dv.get('notes'):
            info_rows.append([
                Paragraph('Notatki wersji', cell_label_style),
                Paragraph(_safe(current_dv['notes']), cell_style),
            ])
    else:
        info_rows.append([
            Paragraph('Wersja dokumentacji', cell_label_style),
            Paragraph('— brak aktywnej wersji —', cell_muted_style),
        ])

    info_table = Table(info_rows, colWidths=[45*mm, doc_width - 45*mm])
    info_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), light_bg),
        ('BOX', (0, 0), (-1, -1), 0.5, grey),
        ('INNERGRID', (0, 0), (-1, -1), 0.25, light_grey),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('PADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 6))

    # ── 2. Werdykt ──────────────────────────────────────────────────────
    story.append(Paragraph('2. WYNIK AKCEPTACJI', section_style))
    verdict = _compute_verdict(
        revision.get('status'), required_roles, approvals, corrections)
    v_bg, v_fg = verdict_palette[verdict['color']]
    verdict_label_style.textColor = v_fg

    verdict_content = [
        Paragraph(verdict['label'], verdict_label_style),
        Spacer(1, 3),
        Paragraph(verdict['desc'], verdict_desc_style),
    ]
    verdict_table = Table([[verdict_content]], colWidths=[doc_width])
    verdict_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), v_bg),
        ('BOX', (0, 0), (-1, -1), 1, v_fg),
        ('LEFTPADDING', (0, 0), (-1, -1), 12),
        ('RIGHTPADDING', (0, 0), (-1, -1), 12),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ]))
    story.append(verdict_table)
    story.append(Spacer(1, 6))

    # ── 3. Wymagane role i ich decyzje ──────────────────────────────────
    story.append(Paragraph('3. WYMAGANE ROLE I ICH DECYZJE', section_style))
    role_rows = [[
        Paragraph('Rola', th_style),
        Paragraph('Osoba', th_style),
        Paragraph('Decyzja', th_style),
        Paragraph('Data', th_style),
        Paragraph('Ważność', th_style),
        Paragraph('Komentarz', th_style),
    ]]

    for rr in required_roles:
        role = rr.get('role', '')
        valid = next((a for a in approvals
                      if a.get('role') == role
                      and a.get('stage', 1) == 1
                      and a.get('validity') == 'WAZNA'), None)
        if valid:
            dec = valid.get('decision', '')
            dec_text = 'Akceptuję' if dec == 'AKCEPTUJE' else 'Wymaga poprawy'
            color = '#065f46' if dec == 'AKCEPTUJE' else '#991b1b'
            role_rows.append([
                Paragraph(role, cell_style),
                Paragraph(_safe(valid.get('full_name')), cell_style),
                Paragraph(f'<font color="{color}"><b>{dec_text}</b></font>', cell_style),
                Paragraph(_to_local(valid.get('created_at')), cell_style),
                Paragraph('Ważna', cell_style),
                Paragraph(_safe(valid.get('comment')), cell_style),
            ])
        else:
            role_rows.append([
                Paragraph(role, cell_style),
                Paragraph('—', cell_muted_style),
                Paragraph('<font color="#92400e">Oczekuje</font>', cell_style),
                Paragraph('—', cell_muted_style),
                Paragraph('—', cell_muted_style),
                Paragraph('—', cell_muted_style),
            ])

    # Etap II (KJ) – dopisz, jeśli to nie jest już w required_roles
    stage2 = next((a for a in approvals
                   if a.get('stage') == 2 and a.get('validity') == 'WAZNA'), None)
    if stage2 and not any(r.get('role') == stage2.get('role') for r in required_roles):
        dec = stage2.get('decision', '')
        dec_text = 'Akceptuję' if dec == 'AKCEPTUJE' else 'Wymaga poprawy'
        color = '#065f46' if dec == 'AKCEPTUJE' else '#991b1b'
        role_rows.append([
            Paragraph(f'{stage2.get("role", "KJ")} (Etap II)', cell_style),
            Paragraph(_safe(stage2.get('full_name')), cell_style),
            Paragraph(f'<font color="{color}"><b>{dec_text}</b></font>', cell_style),
            Paragraph(_to_local(stage2.get('created_at')), cell_style),
            Paragraph('Ważna', cell_style),
            Paragraph(_safe(stage2.get('comment')), cell_style),
        ])

    role_widths = [30*mm, 32*mm, 25*mm, 25*mm, 18*mm, doc_width - 130*mm]
    role_table = Table(role_rows, colWidths=role_widths, repeatRows=1)
    role_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), navy),
        ('BOX', (0, 0), (-1, -1), 0.5, grey),
        ('INNERGRID', (0, 0), (-1, -1), 0.25, light_grey),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('PADDING', (0, 0), (-1, -1), 4),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1),
         [colors.white, colors.HexColor('#f9fafb')]),
    ]))
    story.append(role_table)
    story.append(Spacer(1, 6))

    # ── 4. Zgłoszenia poprawek (jeśli są) ───────────────────────────────
    section_counter = 4
    if corrections:
        story.append(Paragraph(f'{section_counter}. ZGŁOSZENIA POPRAWEK',
                               section_style))
        corr_rows = [[
            Paragraph('#', th_style),
            Paragraph('Zgłaszający', th_style),
            Paragraph('Rola', th_style),
            Paragraph('Opis', th_style),
            Paragraph('Status', th_style),
            Paragraph('Data', th_style),
        ]]
        for i, c in enumerate(corrections, 1):
            corr_rows.append([
                Paragraph(str(i), cell_style),
                Paragraph(_safe(c.get('full_name')), cell_style),
                Paragraph(_safe(c.get('role')), cell_style),
                Paragraph(_safe(c.get('description')), cell_style),
                Paragraph(_safe(c.get('status')), cell_style),
                Paragraph(_to_local(c.get('created_at')), cell_style),
            ])
        corr_widths = [8*mm, 28*mm, 28*mm, doc_width - 108*mm, 22*mm, 22*mm]
        corr_table = Table(corr_rows, colWidths=corr_widths, repeatRows=1)
        corr_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#991b1b')),
            ('BOX', (0, 0), (-1, -1), 0.5, grey),
            ('INNERGRID', (0, 0), (-1, -1), 0.25, light_grey),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('PADDING', (0, 0), (-1, -1), 4),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1),
             [colors.white, colors.HexColor('#fef2f2')]),
        ]))
        story.append(corr_table)
        story.append(Spacer(1, 6))
        section_counter += 1

    # ── 5. Zawartość dokumentacji (jeśli są pliki) ──────────────────────
    if files:
        story.append(Paragraph(f'{section_counter}. ZAWARTOŚĆ DOKUMENTACJI',
                               section_style))
        counts = {}
        for f in files:
            cat = f.get('category', 'other')
            counts[cat] = counts.get(cat, 0) + 1

        order = ['documents', 'bom', 'drawings', 'prototype_photos', 'other']
        sorted_cats = [c for c in order if c in counts]
        sorted_cats += sorted(c for c in counts if c not in order)

        file_rows = [[
            Paragraph('Kategoria', th_style),
            Paragraph('Liczba plików', th_style),
        ]]
        for cat in sorted_cats:
            file_rows.append([
                Paragraph(labels.get(cat, cat), cell_style),
                Paragraph(str(counts[cat]), cell_style),
            ])
        file_rows.append([
            Paragraph('<b>Razem</b>', cell_style),
            Paragraph(f'<b>{len(files)}</b>', cell_style),
        ])
        file_table = Table(file_rows, colWidths=[doc_width - 40*mm, 40*mm])
        file_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), navy),
            ('BOX', (0, 0), (-1, -1), 0.5, grey),
            ('INNERGRID', (0, 0), (-1, -1), 0.25, light_grey),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('PADDING', (0, 0), (-1, -1), 4),
            ('ALIGN', (1, 0), (1, -1), 'CENTER'),
            ('BACKGROUND', (0, -1), (-1, -1), light_bg),
        ]))
        story.append(file_table)
        story.append(Spacer(1, 6))
        section_counter += 1

    # (Sekcja „Miejsce na podpisy" została usunięta – stopka na dole strony
    #  wystarcza jako element identyfikujący dokument.)

    # ── Nagłówek + stopka (rysowane na każdej stronie) ──────────────────
    def _draw_header_footer(canvas, doc_obj):
        """
        Rysuje nagłówek (logo + tytuł + linia) oraz stopkę na każdej stronie.

        Nagłówek: logo 25 mm wysokości po lewej, tytuł dokumentu wyrównany
        do prawego marginesu, pod nimi pozioma linia. Stopka: identyfikator
        raportu + numer strony, oddzielone cienką linią.
        """
        canvas.saveState()
        page_w, page_h = A4

        # ── Nagłówek: logo ─────────────────────────────────────────────
        logo_reader, logo_size = _load_logo()
        if logo_reader:
            iw, ih = logo_size
            logo_h = 25 * mm
            logo_w = logo_h * (iw / ih) if ih else logo_h
            logo_x = 18 * mm
            logo_y = page_h - 5.5 * mm - logo_h
            canvas.drawImage(
                logo_reader, logo_x, logo_y,
                width=logo_w, height=logo_h,
                preserveAspectRatio=True, mask='auto',
            )

        # ── Nagłówek: tytuł (prawa strona) ─────────────────────────────
        canvas.setFillColor(navy)
        canvas.setFont(FONT_BOLD, 11)
        canvas.drawRightString(page_w - 18*mm, page_h - 15*mm,
                               'KARTA AKCEPTACJI')
        canvas.setFont(FONT_REGULAR, 8)
        canvas.drawRightString(page_w - 18*mm, page_h - 20*mm,
                               'DOKUMENTACJI TECHNICZNEJ')

        # ── Nagłówek: linia oddzielająca ───────────────────────────────
        canvas.setStrokeColor(navy)
        canvas.setLineWidth(1)
        canvas.line(18*mm, page_h - 33*mm, page_w - 18*mm, page_h - 33*mm)

        # ── Stopka (bez zmian względem poprzedniej wersji) ─────────────
        canvas.setFont(FONT_REGULAR, 7.5)
        canvas.setFillColor(grey)
        canvas.setStrokeColor(light_grey)
        canvas.setLineWidth(0.3)
        canvas.line(18*mm, 14*mm, page_w - 18*mm, 14*mm)
        canvas.drawString(18*mm, 9*mm, f'AcceptaDoc — {report_id}')
        canvas.drawRightString(page_w - 18*mm, 9*mm, f'Strona {doc_obj.page}')

        canvas.restoreState()

    doc.build(story, onFirstPage=_draw_header_footer,
              onLaterPages=_draw_header_footer)
    return buf.getvalue()