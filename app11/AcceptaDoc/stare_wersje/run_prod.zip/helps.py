"""
Treść strony pomocy systemu AcceptaDoc.

Dlaczego treść w Pythonie, a nie od razu w HTML:
  - Spis treści generuje się automatycznie z listy HELP_SECTIONS.
  - Edycja tekstu nie wymaga znajomości HTML – wystarczy podmienić string.
  - Dodanie nowej sekcji = dopisanie jednego elementu do listy.

Każda sekcja to słownik:
    id     – identyfikator do linków #sekcja-<id>
    icon   – emoji wyświetlane w nagłówku i spisie treści
    title  – tytuł bez numeracji (numer dodaje szablon przez loop.index)
    blocks – lista bloków treści (patrz niżej)

Dostępne typy bloków:
    {'type': 'p',       'text':  '...'}     – akapit
    {'type': 'h3',      'text':  '...'}     – podnagłówek wewnątrz sekcji
    {'type': 'ul',      'items': [...]}     – lista punktowana
    {'type': 'ol',      'items': [...]}     – lista numerowana
    {'type': 'example', 'text':  '...'}     – ramka „Przykład z życia"
    {'type': 'note',    'text':  '...'}     – ramka „Uwaga"

W polach tekstowych można używać prostego HTML: <strong>, <code>, <em>.
Treść pochodzi z tego pliku (nie od użytkownika), więc renderujemy ją
w szablonie z filtrem |safe.
"""

HELP_SECTIONS = [

    # ── 1 ─────────────────────────────────────────────────────────────────
    {
        'id': 'czym-jest',
        'icon': '🎯',
        'title': 'Czym jest AcceptaDoc i po co istnieje',
        'blocks': [
            {'type': 'p', 'text': (
                'AcceptaDoc to firmowy system do zarządzania dokumentacją '
                'techniczną produktów. W jednym miejscu zbieramy rysunki, '
                'specyfikacje, listy materiałów (BOM), zdjęcia prototypów '
                'i inne pliki – przypisane do konkretnego produktu, jego '
                'rewizji oraz konkretnej wersji dokumentacji.'
            )},
            {'type': 'p', 'text': (
                'System nie tworzy dokumentów i nie zastępuje programów CAD. '
                'Jego zadaniem jest pilnowanie porządku: kto, kiedy i którą '
                'wersję dokumentacji zatwierdził. Dzięki temu zawsze wiadomo, '
                'co jest aktualne, a co zostało zastąpione.'
            )},
            {'type': 'h3', 'text': 'Dlaczego w firmie potrzebujemy takiego systemu?'},
            {'type': 'p', 'text': (
                'Bez centralnego systemu dokumentacja rozjeżdża się po mailach, '
                'dyskach sieciowych i prywatnych folderach. Typowe problemy:'
            )},
            {'type': 'ul', 'items': [
                'Dwie osoby pracują na dwóch różnych wersjach tego samego rysunku.',
                'Nikt nie wie, czy jakąś wersję zatwierdził już Konstruktor, czy jeszcze nie.',
                'Produkcja startuje na dokumencie, który dawno został wycofany.',
                'Klient pyta „co zmieniliście między wersjami", a nikt nie potrafi odpowiedzieć.',
                'Podczas audytu nie ma jak pokazać, kto podpisał którą wersję.',
            ]},
            {'type': 'p', 'text': (
                'AcceptaDoc likwiduje te problemy, bo po każdym pliku, każdej '
                'akceptacji i każdej zmianie zostaje ślad w historii.'
            )},
            {'type': 'h3', 'text': 'Co konkretnie robi AcceptaDoc?'},
            {'type': 'ul', 'items': [
                'Przechowuje pliki dokumentacji przypisane do produktu, rewizji i wersji.',
                'Zbiera akceptacje od wymaganych osób (Technolog, Konstruktor, Produkcja, KJ).',
                'Blokuje przejście do produkcji, jeśli brakuje choćby jednej wymaganej akceptacji.',
                'Gdy ktoś zgłosi poprawkę, tworzy nową wersję dokumentacji i unieważnia wcześniejsze akceptacje.',
                'Generuje kartę PDF z pełną historią akceptacji (dowód dla audytu).',
                'Prowadzi dziennik zdarzeń – każde logowanie, akceptacja i upload są zapisane z datą i nazwiskiem.',
            ]},
            {'type': 'example', 'text': (
                'Wyobraź sobie, że Technolog przygotował rysunek nowego elementu '
                'i wrzucił go do systemu. System automatycznie tworzy zadanie '
                'dla Konstruktora i Produkcji. Każdy z nich otwiera ten sam plik, '
                'wyraża swoją opinię (akceptuje albo zgłasza poprawki), a system '
                'zapisuje kto i kiedy to zrobił. Gdy wszyscy zaakceptują, rewizja '
                'trafia do Kontroli Jakości – dopiero po jej zgodzie Produkcja '
                'może wystartować.'
            )},
            {'type': 'note', 'text': (
                'AcceptaDoc to nie jest edytor rysunków. Pliki edytujesz '
                'w swoich programach (AutoCAD, SolidWorks, Excel), a do systemu '
                'wrzucasz już gotowe.'
            )},
        ],
    },

    # ── 2 ─────────────────────────────────────────────────────────────────
    {
        'id': 'jak-dziala',
        'icon': '⚙️',
        'title': 'Jak to działa – przepływ w 30 sekund',
        'blocks': [
            {'type': 'p', 'text': (
                'Żeby zrozumieć system, zapamiętaj trzy poziomy, na których '
                'trzymamy dokumentację:'
            )},
            {'type': 'ol', 'items': [
                '<strong>Produkt</strong> – np. „063-1026-001". Konkretna rzecz, którą robimy.',
                '<strong>Rewizja</strong> – oznaczona jako R01, R02, R03. Duża zmiana w produkcie (np. zmiana konstrukcji, inny materiał, nowy kluczowy dostawca).',
                '<strong>Wersja dokumentacji</strong> – oznaczona jako v001, v002, v003. Mniejsza zmiana w obrębie tej samej rewizji (np. poprawiony wymiar, uzupełniony opis).',
            ]},
            {'type': 'example', 'text': (
                'Produkt 063-1026-001 ma rewizję R01. W obrębie tej rewizji '
                'Technolog najpierw wrzucił rysunek jako v001, potem go poprawił '
                'i wrzucił jako v002. Wersja v001 jest archiwalna (nikt już na '
                'niej nie pracuje), v002 jest aktualna. Jeśli zmieni się coś '
                'większego – np. cała konstrukcja – powstanie rewizja R02.'
            )},
            {'type': 'p', 'text': (
                'Każda wersja dokumentacji przechodzi przez proces akceptacji. '
                'Dopóki brakuje choćby jednej wymaganej akceptacji, wersja nie '
                'może zostać uznana za zatwierdzoną. Akceptacja działa jak podpis '
                'pod dokumentem – bez niego produkcja nie ma zielonego światła.'
            )},
        ],
    },

    # ── 3 ─────────────────────────────────────────────────────────────────
    {
        'id': 'role',
        'icon': '👥',
        'title': 'Role w systemie – kto jest kim',
        'blocks': [
            {'type': 'p', 'text': (
                'W procesie bierze udział kilka ról. Każda ma inne obowiązki '
                'i inne uprawnienia w systemie.'
            )},
            {'type': 'h3', 'text': 'Technolog'},
            {'type': 'p', 'text': (
                'Osoba prowadząca produkt od początku. Zakłada produkt w systemie, '
                'tworzy kolejne rewizje, wybiera, które role muszą zaakceptować '
                'dokumentację, wgrywa pliki i reaguje na zgłoszone poprawki '
                '(poprzez utworzenie nowej wersji dokumentacji). To główny '
                'opiekun produktu w systemie.'
            )},
            {'type': 'h3', 'text': 'Konstruktor'},
            {'type': 'p', 'text': (
                'Odpowiada za poprawność techniczną rysunków i specyfikacji. '
                'Akceptuje dokumentację, jeśli nie ma uwag, albo zgłasza poprawki, '
                'jeśli coś wymaga zmiany. Zwykle jest wymagany w każdej rewizji.'
            )},
            {'type': 'h3', 'text': 'Produkcja – elementy, Produkcja – szycie, Produkcja – zgrzewanie'},
            {'type': 'p', 'text': (
                'Trzy osobne role produkcyjne. Każda patrzy na dokumentację '
                'z punktu widzenia swojego etapu. Akceptują, jeśli da się według '
                'tej dokumentacji wykonać ich część pracy. Jeśli nie – zgłaszają '
                'poprawki.'
            )},
            {'type': 'h3', 'text': 'Kontrola jakości (KJ)'},
            {'type': 'p', 'text': (
                'Wchodzi do akcji na końcu – po tym, jak wszystkie akceptacje '
                'techniczne są już zebrane. Sprawdza pierwszą wyprodukowaną sztukę '
                'i decyduje, czy rewizja może zostać zamknięta jako „zaakceptowana". '
                'Jej zgoda to ostatni krok procesu.'
            )},
            {'type': 'h3', 'text': 'Administrator'},
            {'type': 'p', 'text': (
                'Zarządza użytkownikami (dodawanie, dezaktywacja, reset hasła) '
                'i ma wgląd w dziennik zdarzeń. Nie bierze udziału w akceptacjach '
                'merytorycznych.'
            )},
            {'type': 'example', 'text': (
                'W praktyce: Technolog zakłada produkt i tworzy rewizję, '
                'zaznaczając, że wymaga akceptacji Konstruktora i Produkcji-elementy. '
                'Obaj dostają zadanie. Konstruktor akceptuje od razu, Produkcja '
                'zgłasza poprawkę (brakuje jednego wymiaru). Technolog poprawia '
                'rysunek, tworzy v002 – akceptacja Konstruktora zostaje unieważniona '
                '(bo zmienił się dokument). Obaj akceptują v002. Rewizja trafia '
                'do KJ, która po sprawdzeniu pierwszej sztuki zamyka proces.'
            )},
        ],
    },

    # ── 4 ─────────────────────────────────────────────────────────────────
    {
        'id': 'proces',
        'icon': '📋',
        'title': 'Proces krok po kroku',
        'blocks': [
            {'type': 'p', 'text': (
                'Pełna droga dokumentacji od pustej kartoteki produktu '
                'do zatwierdzonej rewizji:'
            )},
            {'type': 'ol', 'items': [
                '<strong>Utworzenie produktu.</strong> Technolog lub Administrator zakłada produkt w systemie, podając jego numer (np. 063-1026-001) oraz opcjonalnie nazwę i numer zamówienia.',
                '<strong>Utworzenie rewizji.</strong> Do produktu dodaje się pierwszą rewizję (R01). Przy okazji wybiera się, które role muszą zaakceptować dokumentację w tej rewizji (np. Konstruktor, Produkcja-elementy, Produkcja-szycie).',
                '<strong>Wgranie plików.</strong> Do rewizji wgrywa się dokumenty: rysunki, BOM, specyfikacje, zdjęcia prototypu. Pliki są pogrupowane w kategorie, żeby później łatwo je było znaleźć.',
                '<strong>Akceptacje Etapu I.</strong> Wszystkie wymagane role dostają zadania i równolegle wyrażają swoją opinię: „Akceptuję" albo „Wymaga poprawy". Akceptacje są zapisywane z datą, godziną i nazwiskiem.',
                '<strong>Obsługa poprawek.</strong> Jeśli ktokolwiek zgłosił poprawkę, Technolog musi przygotować nową wersję dokumentacji (v002). Nowa wersja unieważnia wszystkie wcześniejsze akceptacje Etapu I i proces zaczyna się od nowa.',
                '<strong>Etap II – Kontrola jakości.</strong> Gdy wszystkie wymagane role zaakceptują bieżącą wersję dokumentacji, rewizja trafia do KJ. KJ sprawdza pierwszą wyprodukowaną sztukę i zatwierdza dokumentację albo odsyła do poprawek.',
                '<strong>Zaakceptowana rewizja.</strong> Po zatwierdzeniu przez KJ rewizja ma status „ZAAKCEPTOWANY". Produkcja może startować. Karta PDF z historią akceptacji jest dostępna do pobrania.',
            ]},
            {'type': 'note', 'text': (
                'Numeracja kroków nie oznacza, że wszystko dzieje się sekwencyjnie. '
                'Akceptacje Etapu I zbierają się równolegle – każda wymagana osoba '
                'może zaakceptować w dowolnym momencie. System pilnuje tylko, '
                'żeby żadna nie została pominięta.'
            )},
        ],
    },

    # ── 5 ─────────────────────────────────────────────────────────────────
    {
        'id': 'etapy',
        'icon': '🪜',
        'title': 'Etap I vs Etap II – dlaczego dwa etapy',
        'blocks': [
            {'type': 'p', 'text': (
                'Akceptacja dokumentacji technicznej odbywa się w dwóch etapach. '
                'To nie jest widzimisię – to realna potrzeba produkcyjna.'
            )},
            {'type': 'h3', 'text': 'Etap I – akceptacje techniczne'},
            {'type': 'p', 'text': (
                'Na tym etapie dokumentację oceniają wszystkie role techniczne: '
                'Technolog, Konstruktor, Produkcja. Każda patrzy ze swojej '
                'perspektywy i odpowiada na pytanie: „Czy według tego dokumentu '
                'da się wykonać moją część pracy?". Etap I kończy się, gdy wszyscy '
                'wymagani zaakceptują bieżącą wersję dokumentacji.'
            )},
            {'type': 'h3', 'text': 'Etap II – Kontrola jakości pierwszej sztuki'},
            {'type': 'p', 'text': (
                'Dopiero gdy dokumentacja jest technicznie spójna, produkcja '
                'wytwarza pierwszą sztukę. Kontrola jakości sprawdza, czy ta '
                'pierwsza sztuka zgadza się z dokumentacją. Jeśli tak – rewizja '
                'zostaje zamknięta jako „ZAAKCEPTOWANY". Jeśli nie – KJ zgłasza '
                'poprawkę i cały proces Etapu I zaczyna się od nowa.'
            )},
            {'type': 'note', 'text': (
                'Etap II jest tylko dla roli Kontrola jakości. Żadna inna rola '
                'nie może zamknąć rewizji końcowo.'
            )},
            {'type': 'example', 'text': (
                'Etap I to „czy rysunek jest poprawny?". Etap II to „czy pierwsza '
                'sztuka wykonana według tego rysunku jest poprawna?". Dopiero oba '
                'etapy dają pełną pewność, że produkt jest gotowy do produkcji '
                'seryjnej.'
            )},
        ],
    },

    # ── 6 ─────────────────────────────────────────────────────────────────
    {
        'id': 'wersje',
        'icon': '🔢',
        'title': 'Wersja dokumentacji – dlaczego to nie to samo co rewizja',
        'blocks': [
            {'type': 'p', 'text': (
                'Rewizja i wersja dokumentacji to dwa różne poziomy zmian. '
                'Pomylenie ich to najczęstszy błąd początkujących użytkowników.'
            )},
            {'type': 'h3', 'text': 'Rewizja (R01, R02, R03)'},
            {'type': 'p', 'text': (
                'To duża zmiana. Zmienia się coś, co wpływa na tożsamość produktu: '
                'konstrukcja, materiał, kluczowy dostawca, funkcja. Nowa rewizja '
                'to praktycznie nowy produkt – ma własny cykl akceptacji od zera.'
            )},
            {'type': 'h3', 'text': 'Wersja dokumentacji (v001, v002, v003)'},
            {'type': 'p', 'text': (
                'To mniejsza zmiana w obrębie tej samej rewizji. Poprawiono wymiar, '
                'uzupełniono opis, wymieniono plik na nowszą wersję tego samego '
                'rysunku. Każda wersja ma własny cykl akceptacji – ale dotyczy '
                'tego samego produktu i tej samej rewizji.'
            )},
            {'type': 'h3', 'text': 'Najważniejsza zasada'},
            {'type': 'p', 'text': (
                'Utworzenie nowej wersji dokumentacji <strong>unieważnia wszystkie '
                'akceptacje Etapu I</strong> dla poprzedniej wersji. To celowe. '
                'Jeśli Konstruktor zaakceptował rysunek, a potem rysunek się '
                'zmienił – jego akceptacja dotyczy starej wersji, nie nowej. '
                'Musi ocenić nową.'
            )},
            {'type': 'note', 'text': (
                'Wyobraź sobie, że podpisałeś umowę, a ktoś potem zmienił w niej '
                'jeden paragraf i twierdzi, że twoja podpisana umowa dalej '
                'obowiązuje. Tak samo jest z akceptacjami – zmiana dokumentu '
                'unieważnia podpisy. Zespół musi ocenić nową wersję.'
            )},
            {'type': 'example', 'text': (
                'Technolog wrzucił rysunek v001. Konstruktor zaakceptował. '
                'Produkcja zgłosiła poprawkę (brakuje wymiaru). Technolog tworzy '
                'v002 z poprawionym rysunkiem. Akceptacja Konstruktora jest teraz '
                'unieważniona, bo dotyczyła v001. Konstruktor musi zaakceptować v002.'
            )},
        ],
    },

    # ── 7 ─────────────────────────────────────────────────────────────────
    {
        'id': 'poprawki',
        'icon': '🔧',
        'title': 'Zgłaszanie poprawek – jak i dlaczego',
        'blocks': [
            {'type': 'p', 'text': (
                'Jeśli ktoś z wymaganych ról uzna, że dokumentacja wymaga zmiany, '
                'nie wpisuje uwag w mailu i nie dzwoni do Technologa. Zgłasza '
                'poprawkę w systemie – wtedy wszystko jest zapisane i widoczne '
                'dla wszystkich.'
            )},
            {'type': 'h3', 'text': 'Jak zgłosić poprawkę'},
            {'type': 'ol', 'items': [
                'Otwórz rewizję i znajdź sekcję „Akceptacje – Etap I".',
                'Kliknij „Wymaga poprawy" zamiast „Akceptuję".',
                'Opisz dokładnie, czego brakuje albo co trzeba zmienić. Im konkretniej, tym szybciej Technolog to poprawi.',
                'Wyślij zgłoszenie. System automatycznie utworzy zadanie dla Technologa.',
            ]},
            {'type': 'h3', 'text': 'Co się dzieje po zgłoszeniu'},
            {'type': 'ul', 'items': [
                'Poprawka pojawia się w sekcji „Zgłoszenia poprawek" na stronie rewizji.',
                'Technolog widzi ją i przygotowuje nową wersję dokumentacji (v002).',
                'Nowa wersja automatycznie zamyka zgłoszenie (status „POPRAWIONE") i unieważnia wszystkie wcześniejsze akceptacje.',
                'Wszyscy wymagani muszą ponownie zaakceptować nową wersję.',
            ]},
            {'type': 'note', 'text': (
                'Poprawka blokuje przejście rewizji do Etapu II, dopóki Technolog '
                'nie utworzy nowej wersji dokumentacji. Nowa wersja unieważnia '
                'wszystkie akceptacje – nawet te, które były już zebrane.'
            )},
        ],
    },

    # ── 8 ─────────────────────────────────────────────────────────────────
    {
        'id': 'pdf',
        'icon': '📄',
        'title': 'Karta PDF – do czego służy',
        'blocks': [
            {'type': 'p', 'text': (
                'Z każdej rewizji można wygenerować kartę PDF. To jeden dokument, '
                'który w zwięzły sposób pokazuje cały stan akceptacji.'
            )},
            {'type': 'h3', 'text': 'Co zawiera karta PDF'},
            {'type': 'ul', 'items': [
                'Numer produktu, nazwa, kod klienta, numer zamówienia.',
                'Oznaczenie rewizji (R01, R02) i wersji dokumentacji (v001, v002).',
                'Lista wymaganych ról i informacja, kto je zaakceptował, kiedy i z jakim komentarzem.',
                'Lista zgłoszonych poprawek (jeśli były).',
                'Data i godzina wygenerowania raportu.',
            ]},
            {'type': 'h3', 'text': 'Jak pobrać kartę'},
            {'type': 'p', 'text': (
                'Otwórz rewizję i kliknij „📄 Karta PDF" w prawym górnym rogu. '
                'Plik pobierze się automatycznie. Każde pobranie jest zapisywane '
                'w dzienniku zdarzeń.'
            )},
            {'type': 'h3', 'text': 'Po co to komu'},
            {'type': 'ul', 'items': [
                '<strong>Dowód dla audytu</strong> – jeden dokument z historią akceptacji.',
                '<strong>Rozliczenie z klientem</strong> – widać, że dokumentacja była zatwierdzona.',
                '<strong>Archiwum</strong> – jeśli kiedyś trzeba wrócić do stanu na dany dzień.',
                '<strong>Komunikacja zewnętrzna</strong> – można wysłać PDF osobie, która nie ma dostępu do systemu.',
            ]},
            {'type': 'note', 'text': (
                'Karta PDF to zrzut stanu w momencie jej wygenerowania. Jeśli po '
                'pobraniu dodadzą się nowe akceptacje, stara karta tego nie pokaże. '
                'Żeby zobaczyć aktualny stan – wygeneruj nową kartę.'
            )},
        ],
    },

    # ── 9 ─────────────────────────────────────────────────────────────────
    {
        'id': 'slownik',
        'icon': '📖',
        'title': 'Słownik pojęć',
        'blocks': [
            {'type': 'p', 'text': (
                'Krótki słownik pojęć, które pojawiają się w systemie. Jeśli nie '
                'wiesz, co znaczy jakieś słowo – zajrzyj tutaj.'
            )},
            {'type': 'h3', 'text': 'Produkt'},
            {'type': 'p', 'text': 'Konkretna rzecz, którą firma produkuje. Oznaczona numerem, np. 063-1026-001.'},
            {'type': 'h3', 'text': 'Rewizja'},
            {'type': 'p', 'text': 'Duża zmiana produktu. Oznaczona jako R01, R02, R03. Każda rewizja ma własny cykl akceptacji.'},
            {'type': 'h3', 'text': 'Wersja dokumentacji'},
            {'type': 'p', 'text': 'Mniejsza zmiana w obrębie jednej rewizji. Oznaczona jako v001, v002, v003. Dotyczy tych samych plików, ale poprawionych.'},
            {'type': 'h3', 'text': 'Akceptacja'},
            {'type': 'p', 'text': 'Formalna decyzja osoby z wymaganej roli, że dokumentacja jest OK („Akceptuję") albo że wymaga zmiany („Wymaga poprawy").'},
            {'type': 'h3', 'text': 'Ważna akceptacja'},
            {'type': 'p', 'text': 'Akceptacja, która dotyczy bieżącej wersji dokumentacji i nie została unieważniona przez nowszą wersję. Tylko takie akceptacje liczą się przy przejściu do kolejnego etapu.'},
            {'type': 'h3', 'text': 'Unieważnienie'},
            {'type': 'p', 'text': 'Sytuacja, w której akceptacja przestaje obowiązywać – dzieje się tak, gdy powstanie nowa wersja dokumentacji. Stara akceptacja zostaje w historii, ale jest oznaczona jako nieważna.'},
            {'type': 'h3', 'text': 'Etap I'},
            {'type': 'p', 'text': 'Pierwszy etap akceptacji – akceptacje techniczne od ról takich jak Konstruktor, Produkcja, Technolog.'},
            {'type': 'h3', 'text': 'Etap II'},
            {'type': 'p', 'text': 'Drugi etap – Kontrola jakości pierwszej sztuki. Kończy proces.'},
            {'type': 'h3', 'text': 'Wymagana rola'},
            {'type': 'p', 'text': 'Rola, która musi zaakceptować daną rewizję. Wybiera je Technolog przy tworzeniu rewizji.'},
            {'type': 'h3', 'text': 'KJ'},
            {'type': 'p', 'text': 'Skrót od „Kontrola jakości". Rola odpowiedzialna za Etap II.'},
            {'type': 'h3', 'text': 'Dziennik zdarzeń'},
            {'type': 'p', 'text': 'Lista wszystkich akcji w systemie – logowań, akceptacji, uploadów plików, utworzenia nowej wersji. Dostępna dla Administratora.'},
        ],
    },

    # ── 10 ────────────────────────────────────────────────────────────────
    {
        'id': 'faq',
        'icon': '❓',
        'title': 'FAQ – najczęstsze pytania',
        'blocks': [
            {'type': 'h3', 'text': 'Dlaczego moja akceptacja zniknęła?'},
            {'type': 'p', 'text': (
                'Jeśli akceptowałeś jakąś wersję dokumentacji, a potem Technolog '
                'wrzucił nowszą wersję, twoja akceptacja została unieważniona. '
                'To normalne – nowa wersja dokumentu wymaga nowej akceptacji. '
                'Twoja akceptacja nie zniknęła całkowicie – jest w historii, '
                'oznaczona jako unieważniona.'
            )},
            {'type': 'h3', 'text': 'Dlaczego nie widzę żadnego zadania do wykonania?'},
            {'type': 'p', 'text': (
                'Zadania widzisz tylko wtedy, gdy twoja rola jest wymagana '
                'w danej rewizji. Jeśli Technolog tworząc rewizję nie zaznaczył '
                'twojej roli, nie dostaniesz zadania – nawet jeśli rewizja '
                'istnieje. Jeśli uważasz, że powinieneś być wymagany, zgłoś to '
                'Technologowi.'
            )},
            {'type': 'h3', 'text': 'Co się dzieje, gdy ktoś zgłosi poprawkę?'},
            {'type': 'p', 'text': (
                'Poprawka pojawia się na stronie rewizji. Rewizja nie może '
                'przejść do Etapu II, dopóki poprawka nie zostanie rozwiązana. '
                'Technolog rozwiązuje ją, tworząc nową wersję dokumentacji. '
                'Wtedy wszyscy wymagani muszą ponownie zaakceptować.'
            )},
            {'type': 'h3', 'text': 'Jak zmienić swoje hasło?'},
            {'type': 'p', 'text': (
                'Kliknij swoje imię w prawym górnym rogu i wybierz „Mój profil". '
                'Tam wpisz aktualne hasło i nowe hasło.'
            )},
            {'type': 'h3', 'text': 'Jak wyszukać produkt?'},
            {'type': 'p', 'text': (
                'W górnej belce jest pole wyszukiwania – wpisz przynajmniej dwa '
                'znaki z numeru, nazwy lub numeru zamówienia. Wyniki pojawią się '
                'pod polem. Możesz też wejść w „Produkty" i użyć pełnej '
                'wyszukiwarki z filtrami.'
            )},
            {'type': 'h3', 'text': 'Kto może tworzyć nowe produkty i rewizje?'},
            {'type': 'p', 'text': (
                'Tylko Technolog i Administrator. Jeśli potrzebujesz nowego '
                'produktu albo rewizji – zgłoś to do jednej z tych osób.'
            )},
            {'type': 'h3', 'text': 'Czy mogę cofnąć swoją akceptację?'},
            {'type': 'p', 'text': (
                'Nie bezpośrednio. Akceptacja jest decyzją formalną. Jeśli '
                'chcesz ją zmienić, skontaktuj się z Technologiem – jedynym '
                'sposobem na „cofnięcie" akceptacji jest utworzenie nowej wersji '
                'dokumentacji, co unieważni wszystkie akceptacje i pozwoli '
                'ocenić dokument na nowo.'
            )},
            {'type': 'h3', 'text': 'Gdzie znajdę historię zmian danej rewizji?'},
            {'type': 'p', 'text': (
                'Na stronie rewizji, w prawej kolumnie, jest sekcja „Historia '
                'zdarzeń". Pokazuje wszystkie akcje związane z tą rewizją, '
                'od najnowszej.'
            )},
        ],
    },

    # ── 11 ────────────────────────────────────────────────────────────────
    {
        'id': 'pierwsze-kroki',
        'icon': '🚀',
        'title': 'Pierwsze kroki dla nowego użytkownika',
        'blocks': [
            {'type': 'p', 'text': (
                'Jeśli to twój pierwszy dzień w systemie, oto co warto zrobić '
                'po kolei.'
            )},
            {'type': 'ol', 'items': [
                '<strong>Zmień hasło.</strong> Kliknij swoje imię w prawym górnym rogu, wybierz „Mój profil" i ustaw własne hasło.',
                '<strong>Sprawdź swoje zadania.</strong> Na „Panelu" zobaczysz sekcję „Moje zadania". Tam pojawiają się rewizje, które czekają na twoją akceptację.',
                '<strong>Otwórz jedno zadanie.</strong> Kliknij „Przejdź do akceptacji". Zobaczysz pliki do przejrzenia, listę wymaganych akceptacji i formularz swojej decyzji.',
                '<strong>Przeczytaj sekcję „Akceptacje Etapu I".</strong> Zobaczysz, kto już zaakceptował, a kto jeszcze czeka. Twój kafelek będzie oznaczony jako „Oczekuje".',
                '<strong>Zaakceptuj albo zgłoś poprawkę.</strong> Jeśli dokumentacja jest OK – kliknij „Akceptuję". Jeśli coś wymaga zmiany – kliknij „Wymaga poprawy" i opisz dokładnie, co poprawić.',
                '<strong>W razie wątpliwości</strong> – zajrzyj do tej pomocy albo zapytaj Technologa.',
            ]},
            {'type': 'note', 'text': (
                'Pierwsze dni w nowym systemie bywają nieintuicyjne. Nie bój się '
                'kliknąć „Wymaga poprawy" zamiast „Akceptuję", jeśli masz '
                'wątpliwości. Lepiej zatrzymać dokument i wyjaśnić niż '
                'zaakceptować coś, co potem trzeba poprawiać w produkcji.'
            )},
        ],
    },
]