// ── Modals ─────────────────────────────────────────
function showModal(id) {
  const el = document.getElementById(id);
  if (el) { el.classList.add('visible'); el.focus(); }
}
function hideModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove('visible');
}
// Close on backdrop click
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('visible');
  }
});
// Close on Escape
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.visible')
      .forEach(m => m.classList.remove('visible'));
  }
});

// ── Global search ──────────────────────────────────
const searchInput = document.getElementById('globalSearch');
const searchResults = document.getElementById('searchResults');
let searchTimer;

if (searchInput) {
  searchInput.addEventListener('input', () => {
    clearTimeout(searchTimer);
    const q = searchInput.value.trim();
    if (q.length < 2) { searchResults.classList.remove('visible'); return; }
    searchTimer = setTimeout(() => fetchSearch(q), 220);
  });
  searchInput.addEventListener('blur', () => {
    setTimeout(() => searchResults.classList.remove('visible'), 200);
  });
}

async function fetchSearch(q) {
  try {
    const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
    const data = await res.json();
    renderSearchResults(data);
  } catch(e) {}
}

function renderSearchResults(items) {
  searchResults.innerHTML = '';
  if (!items.length) {
    searchResults.innerHTML = '<div style="padding:14px;color:#8b949e;font-size:.85rem">Brak wyników</div>';
  } else {
    items.forEach(item => {
      const div = document.createElement('div');
      div.className = 'search-result-item';
      const statusColor = {
        'ETAP_I': '#f59e0b', 'ETAP_II': '#38bdf8', 'ZAAKCEPTOWANY': '#10b981'
      }[item.status] || '#8b949e';
      div.innerHTML = `
        <span class="search-result-num">${item.number}</span>
        <span style="flex:1;font-size:.85rem;color:#c9d1d9">${item.name || ''}</span>
        ${item.letter ? `<span style="font-size:.75rem;color:${statusColor}">${item.status || ''}</span>` : ''}
      `;
      div.addEventListener('click', () => {
        window.location.href = `/products/${item.id}`;
      });
      searchResults.appendChild(div);
    });
  }
  searchResults.classList.add('visible');
}

// ── Table row links ────────────────────────────────
document.querySelectorAll('.table-row-link').forEach(row => {
  row.addEventListener('click', e => {
    if (!e.target.closest('a') && !e.target.closest('button') && !e.target.closest('form')) {
      window.location.href = row.dataset.href;
    }
  });
});

// ── File drop zone ─────────────────────────────────
const dropZone = document.getElementById('dropZone');
const fileInput = document.getElementById('fileInput');
const fileList = document.getElementById('fileList');

if (dropZone && fileInput) {
  ['dragenter','dragover'].forEach(e => {
    dropZone.addEventListener(e, ev => {
      ev.preventDefault();
      dropZone.classList.add('dragging');
    });
  });
  ['dragleave','drop'].forEach(e => {
    dropZone.addEventListener(e, ev => {
      ev.preventDefault();
      dropZone.classList.remove('dragging');
    });
  });
  dropZone.addEventListener('drop', ev => {
    const dt = ev.dataTransfer;
    const files = dt.files;
    updateFileList(files);
    // Also set to file input
    fileInput.files = files;
  });
  fileInput.addEventListener('change', () => updateFileList(fileInput.files));
}

function updateFileList(files) {
  if (!fileList) return;
  fileList.innerHTML = '';
  Array.from(files).forEach(f => {
    const div = document.createElement('div');
    div.className = 'file-list-item';
    const size = f.size > 1024*1024 ? (f.size/1024/1024).toFixed(1)+' MB' : (f.size/1024).toFixed(1)+' KB';
    div.innerHTML = `<span style="font-size:.7rem;background:#6366f1;color:white;padding:1px 5px;border-radius:3px">${f.name.split('.').pop().toUpperCase()}</span><span>${f.name}</span><span style="margin-left:auto;color:#8b949e">${size}</span>`;
    fileList.appendChild(div);
  });
}

// ── Auto-close alerts ──────────────────────────────
setTimeout(() => {
  document.querySelectorAll('.alert').forEach(el => {
    el.style.transition = 'opacity .4s';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 400);
  });
}, 5000);

// ── Letter input uppercase ─────────────────────────
const letterInput = document.getElementById('letter');
if (letterInput) {
  letterInput.addEventListener('input', () => {
    letterInput.value = letterInput.value.toUpperCase();
  });
}
